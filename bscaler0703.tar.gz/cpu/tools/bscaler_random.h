/*
 *        (C) COPYRIGHT Ingenic Limited.
 *             ALL RIGHTS RESERVED
 *
 * File       : bscaler_random.h
 * Authors    : jmqi@joshua
 * Create Time: 2020-06-23:17:24:50
 * Description:
 *
 */

#ifndef __BSCALER_RANDOM_H__
#define __BSCALER_RANDOM_H__
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <string.h>

#include "bscaler_hw_api.h"

bool bsc_random(bs_hw_once_cfg_s *cfg);

void bst_random(bst_hw_once_cfg_s *cfg);

#endif /* __BSCALER_RANDOM_H__ */

