/*
 * Copyright (C) 2018 Ingenic Semiconductor Co.,Ltd
 * File       : inference.h
 * Authors    : dzhang<dong.zhang@ingenic.com>
 * Create Time: 2018-08-27:15:25:37
 * Description: inference.
 *
 */

#ifndef _INFERENCE_H_
#define _INFERENCE_H_
#include <string.h>
#include <map>
#include <vector>
#include <unistd.h>
//#include <random>
#include <fstream>
#include <iostream>
#include <functional>
#include <string.h>
#include <cstring>
#include <assert.h>

using namespace std;

#ifndef __IPL_H__
typedef unsigned char uchar;
typedef unsigned short ushort;
#endif

#ifndef MAX
#  define MAX(a,b)  ((a) < (b) ? (b) : (a))
#endif

enum InterpolationMasks_ingenic {
    INTER_BITS = 10,
    INTER_BITS2 = INTER_BITS * 2,
    INTER_TAB_SIZE = 1 << INTER_BITS,
    INTER_TAB_SIZE2 = INTER_TAB_SIZE * INTER_TAB_SIZE
};

enum img_type {
    YUV = 5, BGR
};

struct Size_Ingenic {
    Size_Ingenic(int w, int h) {
        width = w;
        height = h;

    }

    int area() {
        return width * height;
    }

    int width;
    int height;

};

int test_my_warp_affine_ptr(const uchar* src_ptr, uchar* dst_ptr, int* M, Size_Ingenic ssize,Size_Ingenic dsize);
void quantize_warp_affine_para(float *para, int32_t *quantize_para, int num);

int run_align_pool();
int warp_affine_yuv();

//nv12tobgr
uint8_t satr(float val);
int satr2(int val);
unsigned int yuv2bgr0_c_v2(uint8_t* src,uint8_t* dst,int rows,int cols);

#endif
