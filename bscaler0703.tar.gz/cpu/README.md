##
##        (C) COPYRIGHT Ingenic Limited.
##             ALL RIGHTS RESERVED
##
## File       : README
## Authors    : jmqi@taurus
## Create Time: 2020-06-05:11:36:09
## Description:
##


1) x86 compile
   a) only compile C model
      cmake -DCMAKE_TOOLCHAIN_FILE=../cmake/x86.toolchain.cmake -DMDL_ONLY=ON ..

   b) compile eyer
      cmake -DEYER=ON ..

2) mips compile
   a) CSE
      cmake -DCMAKE_TOOLCHAIN_FILE=../cmake/mips.toolchain.cmake -DCSE=ON ..