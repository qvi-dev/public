/*
 *        (C) COPYRIGHT Ingenic Limited.
 *             ALL RIGHTS RESERVED
 *
 * File       : test_perspective_api.cpp
 * Authors    : jmqi@taurus
 * Create Time: 2020-04-20:11:04:27
 * Description:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "Matrix.h"//not necessary
#include "image_process.h"//not necessary
#include "bscaler_api.h"
#ifdef EYER_SIM_ENV
#include "bscaler_hw_api.h"
#elif CSE_SIM_ENV
#include "bscaler_hw_api.h"
#include "nna_dma_memory.h"
#endif

float pre_matrix[4][9] = {
    { //card0
        0.7432289094520868, 0.3437581877848567, -264.6641702678065,
        -0.08757221079416411, 0.5322170275729831, 17.43920406223504,
        0.0003323120648683242, 0.0002745154549321075, 1
    },
    { //card1
        0.4543057240815148, -0.03131428951546547, -10.80939450940996,
        -0.08699491144180858, 0.2956677276535477, 1.200874691642763,
        0.000327062308108619, -0.000159130143900859, 1
    },
    { //card2
        0.401960601521412, 0.1006454674597662, -77.88406010591774,
        -0.2734789798275858, 0.3457995719465359, 41.80398078520208,
        0.0003258940309528753, -0.0001701695719617651, 1
    },
    {//QR_code
        0.4808396418405373, -0.327522397222399, 0.6270549977433945,
        0.003929922590050981, 0.5495341755088036, -11.59130667935554,
        -0.0002289044767245844, 0.0003870534629624227, 1
    }
};

#ifdef CHIP_SIM_ENV
#define TEST_NAME  t_resize_api
#else
#define TEST_NAME  main
#endif
int TEST_NAME(int argc, char** argv)
{
#ifdef EYER_SIM_ENV
    eyer_system_ini(0);// eyer environment initialize.
    eyer_reg_segv();   // simulation error used
    eyer_reg_ctrlc();  // simulation error used
#elif CSE_SIM_ENV
    bscaler_mem_init();
    int ret = 0;
    if ((ret = nndma_memory_init(0x4000000)) == 0) { //64MB
        printf ("nna box_base virtual generate failed !!\n");
        return 0;
    }
#endif

    uint32_t seed = (uint32_t)time(NULL);
    srand(seed);
    printf("seed = 0x%08x\n", seed);
    const uint32_t coef[9] = {1220542, 1673527, 0,
                              1220542, 409993, 852492,
                              1220542, 2116026, 0};

    const uint32_t offset[2] = {16, 128};

    if (argc < 2) {
        fprintf(stderr, "%s [image_path]/card2.jpg\n", argv[1]);
        exit(1);
    }

    int img_w, img_h, img_chn;
    //uint8_t *img = stbi_load("../image/card2.jpg", &img_w, &img_h, &img_chn, 4);
    uint8_t *img = stbi_load(argv[1], &img_w, &img_h, &img_chn, 4);
    if (img == NULL) {
        fprintf(stderr, "Open input image failed!\n");
        exit(1);
    }
	printf("0x%x,0x%x,0x%x\n",img_w,img_h,img_chn);
    int box_num = 1;
    int dst_w = 96;
    int dst_h = 96;
    int dst_size = dst_w * dst_h * 4 * box_num;
#if (defined CSE_SIM_ENV) || (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    uint8_t *dst_base = (uint8_t *)bscaler_malloc(8, dst_size);
#else
    uint8_t *dst_base = (uint8_t *)malloc(dst_size);
#endif
    if (dst_base == NULL) {
        fprintf(stderr, "alloc failed!\n");
    }
	//for model
	uint8_t *dst_mbase = (uint8_t *)malloc(dst_size);
    if (dst_mbase == NULL) {
        fprintf(stderr, "dst_mbase alloc failed!\n");
    }

#if (defined CSE_SIM_ENV) || (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    uint8_t *src_base = (uint8_t *)bscaler_malloc(1, img_w * img_h * 4);
#else
    uint8_t *src_base = (uint8_t *)malloc(img_w * img_h * 4);
#endif
    if (src_base == NULL) {
        fprintf(stderr, "alloc failed!\n");
    }
    memcpy(src_base, img, img_w * img_h * 4);

    const data_info_s src = {src_base, BS_DATA_ARGB,
                             4, img_h, img_w, img_w * 4};
    data_info_s *dst = (data_info_s *)malloc(sizeof(data_info_s) * box_num);
    for (int i = 0; i < box_num; i++) {
        dst[i].base = dst_base + i * dst_w * dst_h * 4;
        dst[i].format = BS_DATA_ARGB;
        dst[i].chn = 4;
        dst[i].height = dst_h;
        dst[i].width = dst_w;
        dst[i].line_stride = dst_w * 4;
    }
	//dst for model
	data_info_s *m_dst = (data_info_s *)malloc(sizeof(data_info_s) * box_num);

    for (int i = 0; i < box_num; i++) {
        m_dst[i].base = dst_mbase + i * dst_w * dst_h * 4;
        m_dst[i].format = BS_DATA_ARGB;
        m_dst[i].chn = 4;
        m_dst[i].height = dst_h;
        m_dst[i].width = dst_w;
        m_dst[i].line_stride = dst_w * 4;
	}

    box_affine_info_s *infos = (box_affine_info_s *)malloc(sizeof(box_affine_info_s) * box_num);

    for (int i = 0; i < box_num; i++) {
        int src_x = 0;
        int src_y = 0;
        int src_w = img_w;
        int src_h = img_h;

        float *matrix = pre_matrix[2];// 0 - card0, 1 - card1, 2 - card2, 3 - QR_code

        infos[i].box.x = src_x;
        infos[i].box.y = src_y;
        infos[i].box.w = src_w;
        infos[i].box.h = src_h;
        infos[i].matrix[0] = matrix[0];
        infos[i].matrix[1] = matrix[1];
        infos[i].matrix[2] = matrix[2];
        infos[i].matrix[3] = matrix[3];
        infos[i].matrix[4] = matrix[4];
        infos[i].matrix[5] = matrix[5];
        infos[i].matrix[6] = matrix[6];
        infos[i].matrix[7] = matrix[7];
        infos[i].matrix[8] = matrix[8];
        infos[i].wrap = 0;
        infos[i].zero_point = 0;
    }

#if (defined CSE_SIM_ENV) || (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    bs_perspective_start(&src, box_num, dst, infos, coef, offset);
    bs_perspective_wait();
    bs_perspective_mdl(&src, box_num, m_dst, infos, coef, offset);
#else
    bs_perspective_mdl(&src, box_num, dst, infos, coef, offset);
#endif
    printf("============ api finish =============\n");
	// stbi_write_png("out.png", dst_w, dst_h * box_num, 4, dst_base, dst_w * 4);
    stbi_write_jpg("out.jpg", dst_w, dst_h * box_num, 4, dst_base, 100);
	//check
	int errflag = 0;
	for(int bid = 0; bid < box_num; bid++){
		uint8_t *gld_ptr = (uint8_t *)dst_mbase;
		uint8_t *dut_ptr = (uint8_t *)dst_base;
		for (int i = 0; i < dst_h; i++) {
			for (int j = 0; j < dst_w; j++) {
				for (int k = 0; k < 3; k++) {//NOT
					uint8_t g_val = gld_ptr[i * dst_w * 4 + j * 4 + k];
					uint8_t d_val = dut_ptr[i * dst_w * 4 + j * 4 + k];
					if (g_val != d_val) {
						errflag =1;
						printf("[failed] (0x%x,0x%x,0x%x) : (G) 0x%x -- (E) 0x%x\n", j, i, k, g_val, d_val);
					}
				}
			}
		}
	}
	if(errflag==1){
		printf("simulation failed!\n");
	}else{
		printf("simulation sucessed!\n");
	}

#if (defined CSE_SIM_ENV) || (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    bscaler_free(dst_base);
    bscaler_free(src_base);
#else
    free(dst_base);
    free(src_base);
#endif
    free(dst);
    free(infos);
    stbi_image_free(img);
#ifdef EYER_SIM_ENV
    eyer_stop();
#endif
    return 0;
}
