#ifndef __BSCALER_HW_API_H__
#define __BSCALER_HW_API_H__
#if ( !defined(EYER_SIM_ENV) && !defined(CSE_SIM_ENV) && !defined(MDL_ONLY) )
#define CHIP_SIM_ENV
#endif

#ifdef EYER_SIM_ENV
#include "eyer_driver.h"
#include <stdint.h>
#endif

#ifdef CSE_SIM_ENV
#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include <float.h>
#include "nna_dma_memory.h"
#include "oram_mem.h"
#include "ddr_mem.h"
#include "soc_nna.h"
#endif

#ifdef CHIP_SIM_ENV
#include "platform.h"
#else
#include <stdint.h>
#include <stdbool.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SRC_CPU
#define BSCALER_BASE                0xB3090000
#else
#define BSCALER_BASE                0x13090000
#endif

#define BSCALER_FRMC_CTRL           (0*4)
#define BSCALER_FRMC_MODE           (1*4)
#define BSCALER_FRMC_YBASE_SRC      (2*4)
#define BSCALER_FRMC_CBASE_SRC      (3*4)
#define BSCALER_FRMC_WH_SRC         (4*4)
#define BSCALER_FRMC_PS_SRC         (5*4)
#define BSCALER_FRMC_BASE_DST       (6*4)
#define BSCALER_FRMC_WH_DST         (7*4)
#define BSCALER_FRMC_PS_DST         (8*4)
#define BSCALER_FRMC_BOX_BASE       (9*4)
#define BSCALER_FRMC_MONO           (10*4)
#define BSCALER_FRMC_EXTREME_Y      (11*4)

#define BSCALER_FRMC_CHAIN_CTRL     (12*4)
#define BSCALER_FRMC_CHAIN_BASE     (13*4)
#define BSCALER_FRMC_CHAIN_LEN      (14*4)
#define BSCALER_FRMC_BUS            (15*4)

#define BSCALER_FRMC_BOX0           (16*4)
#define BSCALER_FRMC_BOX1           (17*4)
#define BSCALER_FRMC_BOX2           (18*4)
#define BSCALER_FRMC_BOX3           (19*4)
#define BSCALER_FRMC_BOX4           (20*4)
#define BSCALER_FRMC_BOX5           (21*4)
#define BSCALER_FRMC_BOX6           (22*4)
#define BSCALER_FRMC_BOX7           (23*4)
#define BSCALER_FRMC_BOX8           (24*4)
#define BSCALER_FRMC_BOX9           (25*4)
#define BSCALER_FRMC_BOX10          (26*4)

#define BSCALER_FRMT_CTRL           (32*4)
#define BSCALER_FRMT_TASK           (33*4)
#define BSCALER_FRMT_YBASE_SRC      (34*4)
#define BSCALER_FRMT_CBASE_SRC      (35*4)
#define BSCALER_FRMT_WH_SRC         (36*4)
#define BSCALER_FRMT_PS_SRC         (37*4)
#define BSCALER_FRMT_YBASE_DST      (38*4)
#define BSCALER_FRMT_CBASE_DST      (39*4)
#define BSCALER_FRMT_FS_DST         (40*4)
#define BSCALER_FRMT_PS_DST         (41*4)
#define BSCALER_FRMT_DUMMY          (42*4)
#define BSCALER_FRMT_FORMAT         (43*4)

#define BSCALER_FRMT_CHAIN_CTRL     (44*4)
#define BSCALER_FRMT_CHAIN_BASE     (45*4)
#define BSCALER_FRMT_CHAIN_LEN      (46*4)
#define BSCALER_FRMT_BUS            (47*4)

#define BSCALER_PARAM0              (48*4)
#define BSCALER_PARAM1              (49*4)
#define BSCALER_PARAM2              (50*4)
#define BSCALER_PARAM3              (51*4)
#define BSCALER_PARAM4              (52*4)
#define BSCALER_PARAM5              (53*4)
#define BSCALER_PARAM6              (54*4)
#define BSCALER_PARAM7              (55*4)
#define BSCALER_PARAM8              (56*4)
#define BSCALER_PARAM9              (57*4)
#define BSCALER_CFG                 (58*4)

#define BSCALER_FRMT_ISUM           (60*4)
#define BSCALER_FRMT_OSUM           (61*4)
#define BSCALER_FRMC_ISUM           (62*4)
#define BSCALER_FRMC_OSUM           (63*4)

typedef struct {
    uint8_t                     src_format; //0: nv12; 1: bgr
    uint8_t                     dst_format; //0: nv12; 1: bgr; 2: nv22; 3: kernel;
    uint8_t                     kernel_size; //0: 1x1; 1: 3x3; 2: 5x5; 3: 7x7
    uint8_t                     kernel_xstride; //1~3;
    uint8_t                     kernel_ystride; //1~3;
    uint32_t                    kernel_dummy_val;
    uint8_t                     panding_lf; //left panding edge.
    uint8_t                     panding_rt; //right panding edge.
    uint8_t                     panding_tp; //top panding edge.
    uint8_t                     panding_bt; //botom panding edge.
    uint32_t                    frmt_task_len;
    uint32_t                    frmt_bus; //[0]: chain; [1]: ibuft; [2]: obuft
    uint8_t                     *src_base0; //34[31:5]
    uint8_t                     *src_base1; //35[31:5]
    uint32_t                    src_w; //36[15:1]
    uint32_t                    src_h; //36[31:17]
    uint32_t                    src_line_stride; //37[15:5]
    uint8_t                     *dst_base0; //38[31:5]
    uint8_t                     *dst_base1; //38[31:5]
    uint32_t                    dst_line_stride; //39[15:5]
    uint32_t                    frmt_fs_dst;
    uint32_t                    nv2bgr_order;
    uint32_t                    nv2bgr_coef[9];
    uint8_t                     nv2bgr_ofst[2];
    uint32_t                    isum;
    uint32_t                    osum;
    uint32_t                    irq_mask;
} bst_hw_once_cfg_s;

typedef enum {
    BST_HW_DATA_FM_NV12         = 0,  //000,0000
    BST_HW_DATA_FM_BGRA         = 1,  //000,0001
    BST_HW_DATA_FM_VIR          = 3,  //000,0011
} bst_hw_data_format_e;

typedef enum {
    BS_HW_DATA_FM_NV12          = 0,  //000,0000
    BS_HW_DATA_FM_BGRA          = 1,  //000,0001
    BS_HW_DATA_FM_GBRA          = 3,  //000,0011
    BS_HW_DATA_FM_RBGA          = 5,  //000,0101
    BS_HW_DATA_FM_BRGA          = 7,  //000,0111
    BS_HW_DATA_FM_GRBA          = 9,  //000,1001
    BS_HW_DATA_FM_RGBA          = 11, //000,1011
    BS_HW_DATA_FM_ABGR          = 17, //001,0001
    BS_HW_DATA_FM_AGBR          = 19, //001,0011
    BS_HW_DATA_FM_ARBG          = 21, //001,0101
    BS_HW_DATA_FM_ABRG          = 23, //001,0111
    BS_HW_DATA_FM_AGRB          = 25, //001,1001
    BS_HW_DATA_FM_ARGB          = 27, //001,1011
    BS_HW_DATA_FM_F32_2B        = 33, //010,0001
    BS_HW_DATA_FM_F32_4B        = 65, //100,0001
    BS_HW_DATA_FM_F32_8B        = 97, //110,0001
} bs_hw_data_format_e;

/**
 * for bscaler hardware API, doing once
 */
typedef struct {
    //single source box info
    uint8_t                     *src_base0;
    uint8_t                     *src_base1;
    bs_hw_data_format_e         src_format;
    uint32_t                    src_line_stride;
    uint32_t                    src_box_x;
    uint32_t                    src_box_y;
    uint32_t                    src_box_w;
    uint32_t                    src_box_h;

    //single destination box info(size must same)
    bs_hw_data_format_e         dst_format;
    uint32_t                    dst_line_stride;
    uint32_t                    dst_box_x;
    uint32_t                    dst_box_y;
    uint32_t                    dst_box_w;
    uint32_t                    dst_box_h;

    bool                        affine;
    bool                        box_mode;
    uint32_t                    y_gain_exp;
    uint8_t                     zero_point;
    uint32_t                    coef[9];
    uint8_t                     offset[2];
    int32_t                     matrix[9];

    //line mode, multi-box info
    uint32_t                    box_num;//only for hw_api
    uint8_t                     *dst_base[64];
    uint32_t                    *boxes_info;
    /*
      box_base[0] = src_box_x << 16 | src_box_y
      box_base[1] = src_box_w << 16 | src_box_h
      box_base[2] = scale_x
      box_base[3] = scale_y
      box_base[4] = trans_x
      box_base[5] = trans_y
    */

    uint8_t                     mono_x;
    uint8_t                     mono_y;
    int8_t                      extreme_point[64];
    uint32_t                    isum;
    uint32_t                    osum;
    uint8_t                     bus;//[0]-chain,[1]-box,[2]-ibuf,[3]-obuf, 0-ddr, 1-oram
    uint8_t                     irq_mask;//1 - mask

} bs_hw_once_cfg_s;

typedef struct {
	//for chain
	uint32_t                    *bs_chain_base;
	uint32_t                    bs_chain_len;
	uint8_t                     bs_chain_irq;
} bs_chain_cfg_s;

typedef struct {
	uint32_t                    *bs_ret_base;
	uint32_t                    bs_ret_len;	
} bs_chain_ret_s;



void bscaler_mem_init();
void *bscaler_malloc(size_t align, size_t size);
void bscaler_free(void *p2);
void *bscaler_malloc_oram(size_t align, size_t size);
void bscaler_free_oram(void *p2);

void bscaler_write_reg(uint32_t reg, uint32_t val);
uint32_t bscaler_read_reg(uint32_t reg, uint32_t val);

uint32_t bscaler_softreset_set();
uint32_t bscaler_clkgate_mask_set(uint32_t t, uint32_t c);

uint32_t bscaler_frmt_cfg(bst_hw_once_cfg_s *cfg);
uint32_t bscaler_frmc_cfg(bs_hw_once_cfg_s *cfg);

void bscaler_frmt_write_chain(uint32_t reg, uint32_t val, uint32_t *addr, uint32_t tm);
uint32_t bscaler_frmt_cfg_chain(bst_hw_once_cfg_s *pre, bst_hw_once_cfg_s *cur, uint32_t *addr);

void bscaler_frmc_write_chain(uint32_t reg, uint32_t val, uint32_t *addr, uint32_t tm);
bs_chain_ret_s bscaler_frmc_chain_cfg(bs_hw_once_cfg_s *cfg, uint32_t *addr);
void bsc_chain_hw_cfg(bs_chain_cfg_s cfg);
	
#ifdef __cplusplus
}
#endif
#endif //__BSCALER_HW_API_H__
