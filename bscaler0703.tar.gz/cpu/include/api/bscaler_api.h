/*
 *        (C) COPYRIGHT Ingenic Limited.
 *             ALL RIGHTS RESERVED
 *
 * File       : bscaler_api.h
 * Authors    : jmqi@taurus
 * Create Time: 2020-04-02:15:50:09
 * Description:
 *
 */

#ifndef __BSCALER_API_H__
#define __BSCALER_API_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int                 x;
    int                 y;
    int                 w;
    int                 h;
} box_info_s;

typedef struct {
    box_info_s          box;//source box
    float               matrix[9];//fixme
    uint32_t            wrap;
    uint32_t            zero_point;
} box_affine_info_s;

typedef struct {
    box_info_s          box;//source box
    float               matrix[9];
    uint32_t            wrap;
    uint32_t            zero_point;
} box_perspective_info_s;

typedef struct {
    box_info_s          box;//source box
    uint32_t            wrap;
    uint32_t            zero_point;
} box_resize_info_s;

typedef enum {
    BS_DATA_NV12        = 0,  //000,0000
    BS_DATA_BGRA        = 1,  //000,0001
    BS_DATA_GBRA        = 3,  //000,0011
    BS_DATA_RBGA        = 5,  //000,0101
    BS_DATA_BRGA        = 7,  //000,0111
    BS_DATA_GRBA        = 9,  //000,1001
    BS_DATA_RGBA        = 11, //000,1011
    BS_DATA_ABGR        = 17, //001,0001
    BS_DATA_AGBR        = 19, //001,0011
    BS_DATA_ARBG        = 21, //001,0101
    BS_DATA_ABRG        = 23, //001,0111
    BS_DATA_AGRB        = 25, //001,1001
    BS_DATA_ARGB        = 27, //001,1011
    BS_DATA_FMU2        = 32, //010,0000
    BS_DATA_FMU4        = 64, //100,0000
    BS_DATA_FMU8        = 96, //110,0000
} bs_data_format_e;

typedef struct {
    void                *base;
    bs_data_format_e    format;
    int                 chn;
    int                 height;
    int                 width;
    int                 line_stride;
} data_info_s;

int bs_covert_cfg(const data_info_s *src, const data_info_s *dst);

int bs_covert_step_start(const int line);

int bs_covert_step_wait();

int bs_cropbox_start(const data_info_s *src,
                     const int box_num, const data_info_s *dst,
                     const uint32_t *coef, const uint32_t *offset);

int bs_cropbox_wait();

int bs_perspective_start(const data_info_s *src,
                         const int box_num, const data_info_s *dst,
                         const box_affine_info_s *boxes,
                         const uint32_t *coef, const uint32_t *offset);
int bs_perspective_wait();

int bs_affine_start(const data_info_s *src,
                    const int box_num, const data_info_s *dst,
                    const box_affine_info_s *boxes,
                    const uint32_t *coef, const uint32_t *offset);
int bs_affine_wait();

int bs_resize_start(const data_info_s *src,
                    const int box_num, const data_info_s *dst,
                    const box_resize_info_s *boxes,
                    const uint32_t *coef, const uint32_t *offset);

int bs_resize_wait();

//////////////////////////////////////////////////////////////////
int bs_perspective_mdl(const data_info_s *src,
                       const int box_num, const data_info_s *dst,
                       const box_affine_info_s *boxes,
                       const uint32_t *coef, const uint32_t *offset);

int bs_affine_mdl(const data_info_s *src,
                  const int box_num, const data_info_s *dst,
                  const box_affine_info_s *boxes,
                  const uint32_t *coef, const uint32_t *offset);

int bs_resize_mdl(const data_info_s *src,
                  const int box_num, const data_info_s *dst,
                  const box_resize_info_s *boxes,
                  const uint32_t *coef, const uint32_t *offset);

#ifdef __cplusplus
}
#endif
#endif /* __BSCALER_API_H__ */
