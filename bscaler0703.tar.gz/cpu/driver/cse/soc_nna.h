#ifndef __SOC_NNA_H__
#define __SOC_NNA_H__

#include <stdbool.h>

/* IOCTL MACRO DEFINE PLACE */
#define SOC_NNA_MAGIC               'c'
#define IOCTL_SOC_NNA_MALLOC        _IOWR(SOC_NNA_MAGIC, 0, int)
#define IOCTL_SOC_NNA_FREE          _IOWR(SOC_NNA_MAGIC, 1, int)
#define IOCTL_SOC_NNA_FLUSHCACHE    _IOWR(SOC_NNA_MAGIC, 2, int)

/*
 * dir value defined in  enum dma_data_direction in linux/dma-direction.h
 * 0:DMA_BIDIRECTIONAL, 1:DMA_TO_DEVICE, 2:DMA_FROM_DEVICE
 */
struct flush_cache_info {
    unsigned int    addr;
    unsigned int    len;
    unsigned int    dir;
};

struct soc_nna_buf {
    void        *vaddr;
    void        *paddr;
    int         size;
};

#endif
