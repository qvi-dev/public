/*
 *        (C) COPYRIGHT Ingenic Limited.
 *             ALL RIGHTS RESERVED
 *
 * File       : bscaler_hw_api.c
 * Authors    : jmqi@taurus
 * Create Time: 2020-04-20:15:02:19
 * Description:
 *
 */
#include <stdio.h>
#include <assert.h>

#include "bscaler_hw_api.h"

#ifdef CSE_SIM_ENV
void *bscaler_base_vaddr = NULL;
void *bscaler_base_paddr = NULL;
int bscaler_base_size = 0;

void bscaler_mem_init()
{
    int memfd = open("/dev/mem", O_RDWR | O_SYNC);
    if (memfd  < 0) {
        printf("open /dev/mem failed:%s\n", strerror(errno));
        goto err_open_mem;
    }
    bscaler_base_paddr = (void *)BSCALER_BASE;
    bscaler_base_size = 0x00001000;
    bscaler_base_vaddr = mmap(NULL, bscaler_base_size, PROT_READ | PROT_WRITE,
                              MAP_SHARED, memfd, (off_t)bscaler_base_paddr);
    if (bscaler_base_vaddr == MAP_FAILED) {
        fprintf(stderr, "mmap paddr=%p size=0x%08x failed:%s\n",
                bscaler_base_paddr, bscaler_base_size, strerror(errno));
        goto err_mmap_nnbscaler;
    }
err_open_mem:
err_mmap_nnbscaler:
    close(memfd);
    memfd = -1;
}
#endif

void *bscaler_malloc(size_t align, size_t size)
{
    if (align <= 0)
        printf("error: bscaler_malloc, align = %0d\n", align);
    void *p1;
    void **p2;
    int offset = align - 1 + sizeof(void *);
#ifdef EYER_SIM_ENV
    p1 = malloc(size + offset);
#endif

#ifdef CSE_SIM_ENV
    p1 = ddr_malloc(size + offset);
#endif
    if (p1 == NULL) {
        printf("error: bscaler malloc failed!\n");
        return NULL;
    }
    p2 = (void **)(((size_t)p1 + offset) & (~(align - 1)));
    p2[-1] = p1;
    return p2;
}

void bscaler_free(void *p2)
{
    void *p1 = ((void**)p2)[-1];
#ifdef EYER_SIM_ENV
    free(p1);
#endif

#ifdef CSE_SIM_ENV
    ddr_free(p1);
#endif
}

void *bscaler_malloc_oram(size_t align, size_t size)
{
    if (align <= 0)
        printf("error: bscaler_malloc_oram, align = %0d\n", align);
    void *p1;
    void **p2;
    int offset = align - 1 + sizeof(void *);
#ifdef EYER_SIM_ENV
    p1 = malloc(size + offset);
#endif

#ifdef CSE_SIM_ENV
    p1 = oram_malloc(size + offset);
#endif
    if (p1 == NULL) {
        printf("error: bscaler malloc failed!\n");
        return NULL;
    }
    p2 = (void **)(((size_t)p1 + offset) & (~(align - 1)));
    p2[-1] = p1;
    return p2;
}

void bscaler_free_oram(void *p2)
{
    void *p1 = ((void**)p2)[-1];
#ifdef EYER_SIM_ENV
    free(p1);
#endif

#ifdef CSE_SIM_ENV
    oram_free(p1);
#endif
}

void bscaler_write_reg(uint32_t reg, uint32_t val)
{
#ifdef EYER_SIM_ENV
    write_reg(BSCALER_BASE + reg, val);
#endif

#ifdef CSE_SIM_ENV
    *(volatile unsigned int*)(bscaler_base_vaddr + reg) = val;
#endif

#ifdef CHIP_SIM_ENV
    plat_write_reg(BSCALER_BASE + reg, val);
#endif
}

uint32_t bscaler_read_reg(uint32_t reg, uint32_t val)
{
#ifdef EYER_SIM_ENV
    return (read_reg(BSCALER_BASE + reg, 0));
#endif

#ifdef CSE_SIM_ENV
    return (*(volatile unsigned int*)(bscaler_base_vaddr + reg));
#endif

#ifdef CHIP_SIM_ENV
    return (plat_read_reg(BSCALER_BASE + reg));
#endif

}

void bscaler_frmc_write_chain(uint32_t reg, uint32_t val, uint32_t *addr, uint32_t tm)
{
    *addr = val;
    *(addr+1) = (tm << 31) | reg;
}

uint32_t bscaler_softreset_set()//should be fix
{
    bscaler_write_reg(BSCALER_CFG, 1);
    while (bscaler_read_reg(BSCALER_CFG, 0) != 0);
}

uint32_t bscaler_clkgate_mask_set(uint32_t t, uint32_t c) //should be fix
{
    bscaler_write_reg(BSCALER_CFG, t << 2 | c <<3);
}

uint32_t bscaler_param_cfg(uint32_t nv2bgr_coef[9],
                           uint8_t nv2bgr_ofst[2], uint8_t nv2bgr_order)
{
    uint32_t c00 = nv2bgr_coef[0];
    uint32_t c01 = nv2bgr_coef[1];
    uint32_t c02 = nv2bgr_coef[2];
    uint32_t c03 = nv2bgr_coef[3];
    uint32_t c04 = nv2bgr_coef[4];
    uint32_t c05 = nv2bgr_coef[5];
    uint32_t c06 = nv2bgr_coef[6];
    uint32_t c07 = nv2bgr_coef[7];
    uint32_t c08 = nv2bgr_coef[8];
    uint8_t ofst_y = nv2bgr_ofst[0];
    uint8_t ofst_c = nv2bgr_ofst[1];
    bscaler_write_reg(BSCALER_PARAM0,  (c00 << 0));
    bscaler_write_reg(BSCALER_PARAM1,  (c01 << 0));
    bscaler_write_reg(BSCALER_PARAM2,  (c02 << 0));
    bscaler_write_reg(BSCALER_PARAM3,  (c03 << 0));
    bscaler_write_reg(BSCALER_PARAM4,  (c04 << 0));
    bscaler_write_reg(BSCALER_PARAM5,  (c05 << 0));
    bscaler_write_reg(BSCALER_PARAM6,  (c06 << 0));
    bscaler_write_reg(BSCALER_PARAM7,  (c07 << 0));
    bscaler_write_reg(BSCALER_PARAM8,  (c08 << 0));
    bscaler_write_reg(BSCALER_PARAM9,  ((ofst_y << 16) |
                                        (ofst_c << 24) |
                                        (nv2bgr_order & 0xf) << 0));
}

uint32_t bscaler_frmt_cfg(bst_hw_once_cfg_s *cfg)
{

    bscaler_param_cfg(cfg->nv2bgr_coef, cfg->nv2bgr_ofst, cfg->nv2bgr_order);
    bscaler_write_reg(BSCALER_FRMT_BUS, cfg->frmt_bus);
#ifdef EYER_SIM_ENV
    bscaler_write_reg(BSCALER_FRMT_YBASE_SRC, cfg->src_base0);
    bscaler_write_reg(BSCALER_FRMT_CBASE_SRC, cfg->src_base1);
    bscaler_write_reg(BSCALER_FRMT_YBASE_DST, cfg->dst_base0);
    bscaler_write_reg(BSCALER_FRMT_CBASE_DST, cfg->dst_base1);
#endif

#ifdef CSE_SIM_ENV
    if ((cfg->frmt_bus >> 1) & 0x1) {
        bscaler_write_reg(BSCALER_FRMT_YBASE_SRC,
                          (uint32_t)nndma_oram_vir_to_phy(cfg->src_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_SRC,
                          (uint32_t)nndma_oram_vir_to_phy(cfg->src_base1));
    } else {
        bscaler_write_reg(BSCALER_FRMT_YBASE_SRC,
                          (uint32_t)nndma_ddr_vir_to_phy(cfg->src_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_SRC,
                          (uint32_t)nndma_ddr_vir_to_phy(cfg->src_base1));
    }
    if ((cfg->frmt_bus >> 2) & 0x1) {
        bscaler_write_reg(BSCALER_FRMT_YBASE_DST,
                          (uint32_t)nndma_oram_vir_to_phy(cfg->dst_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_DST,
                          (uint32_t)nndma_oram_vir_to_phy(cfg->dst_base1));
    } else {
        bscaler_write_reg(BSCALER_FRMT_YBASE_DST,
                          (uint32_t)nndma_ddr_vir_to_phy(cfg->dst_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_DST,
                          (uint32_t)nndma_ddr_vir_to_phy(cfg->dst_base1));
    }
#endif

#ifdef CHIP_SIM_ENV
    if ((cfg->frmt_bus >> 1) & 0x1) {//oram
        bscaler_write_reg(BSCALER_FRMT_YBASE_SRC,
                          (uint32_t)plat_va_2_pa(cfg->src_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_SRC,
                          (uint32_t)plat_va_2_pa(cfg->src_base1));
    } else {//ddr
        bscaler_write_reg(BSCALER_FRMT_YBASE_SRC,
                          (uint32_t)plat_va_2_pa(cfg->src_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_SRC,
                          (uint32_t)plat_va_2_pa(cfg->src_base1));
    }
    if ((cfg->frmt_bus >> 2) & 0x1) {//oram
        bscaler_write_reg(BSCALER_FRMT_YBASE_DST,
                          (uint32_t)plat_va_2_pa(cfg->dst_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_DST,
                          (uint32_t)plat_va_2_pa(cfg->dst_base1));
    } else {//ddr
        bscaler_write_reg(BSCALER_FRMT_YBASE_DST,
                          (uint32_t)plat_va_2_pa(cfg->dst_base0));
        bscaler_write_reg(BSCALER_FRMT_CBASE_DST,
                          (uint32_t)plat_va_2_pa(cfg->dst_base1));
    }
#endif
    bscaler_write_reg(BSCALER_FRMT_WH_SRC, (cfg->src_h << 16 |
                                            cfg->src_w));
    bscaler_write_reg(BSCALER_FRMT_PS_SRC, (cfg->src_line_stride & 0xFFFF));
    bscaler_write_reg(BSCALER_FRMT_PS_DST, cfg->dst_line_stride);
    bscaler_write_reg(BSCALER_FRMT_FS_DST, cfg->frmt_fs_dst);
    bscaler_write_reg(BSCALER_FRMT_DUMMY, cfg->kernel_dummy_val);
    bscaler_write_reg(BSCALER_FRMT_FORMAT, ((cfg->src_format & 0x1) << 0 | //[1:0]
                                            (cfg->dst_format & 0x3) << 2 | //[3:2]
                                            (cfg->kernel_xstride & 0x3) << 4 | //[5:4]
                                            (cfg->kernel_ystride & 0x3) << 6 | //[7:6]
                                            (cfg->kernel_size & 0x3) << 8 | //[9:8]
                                            (cfg->panding_lf & 0x7) << 16 | //[18:16]
                                            (cfg->panding_rt & 0x7) << 20 | //[22:20]
                                            (cfg->panding_tp & 0x7) << 24 | //[26:24]
                                            (cfg->panding_bt & 0x7) << 28)); //[30:28]
    bscaler_write_reg(BSCALER_FRMT_ISUM, 0); //clear summary
    bscaler_write_reg(BSCALER_FRMT_OSUM, 0); //clear summary
    bscaler_write_reg(BSCALER_FRMT_CTRL, ((cfg->irq_mask & 0x1) << 4 | 1));
}

uint32_t bscaler_frmc_cfg(bs_hw_once_cfg_s *cfg)
{
    uint8_t nv2bgr_order = (cfg->src_format >> 1) & 0xF;
    bscaler_param_cfg(cfg->coef, cfg->offset, nv2bgr_order);
    uint32_t i;
    uint32_t box_num;
    uint32_t src_format = cfg->src_format & 0x1;
    uint32_t dst_format = cfg->dst_format & 0x1;
    uint32_t bpp_mode = (cfg->src_format >> 5) & 0x3;
    if (!dst_format)
        box_num = 2;
    else
        box_num = cfg->box_num;

#ifdef EYER_SIM_ENV
    bscaler_write_reg(BSCALER_FRMC_YBASE_SRC, (uint32_t)(cfg->src_base0));
    bscaler_write_reg(BSCALER_FRMC_CBASE_SRC, (uint32_t)(cfg->src_base1));

    for (i = 0; i < box_num; i++) {
        bscaler_write_reg(BSCALER_FRMC_BASE_DST, (uint32_t)cfg->dst_base[i]);
    }
    bscaler_write_reg(BSCALER_FRMC_BOX_BASE, (uint32_t)cfg->boxes_info);
#endif

#ifdef CSE_SIM_ENV
    if ((cfg->bus >> 2) & 0x1) {
        bscaler_write_reg(BSCALER_FRMC_YBASE_SRC,
                          (uint32_t)nndma_oram_vir_to_phy((uint32_t)(cfg->src_base0)));
        bscaler_write_reg(BSCALER_FRMC_CBASE_SRC,
                          (uint32_t)nndma_oram_vir_to_phy((uint32_t)(cfg->src_base1)));
    } else {
        bscaler_write_reg(BSCALER_FRMC_YBASE_SRC,
                          (uint32_t)nndma_ddr_vir_to_phy((uint32_t)(cfg->src_base0)));
        bscaler_write_reg(BSCALER_FRMC_CBASE_SRC,
                          (uint32_t)nndma_ddr_vir_to_phy((uint32_t)(cfg->src_base0)));
    }
    for (i = 0; i < box_num; i++) {
        if ((cfg->bus >> 3) & 0x1) {
            bscaler_write_reg(BSCALER_FRMC_BASE_DST,
                              (uint32_t)nndma_oram_vir_to_phy((uint32_t)cfg->dst_base[i]));
        } else {
            bscaler_write_reg(BSCALER_FRMC_BASE_DST,
                              (uint32_t)nndma_ddr_vir_to_phy((uint32_t)cfg->dst_base[i]));
        }
    }
    if ((cfg->bus >> 1) & 0x1) {
        bscaler_write_reg(BSCALER_FRMC_BOX_BASE,
                          (uint32_t)nndma_oram_vir_to_phy((uint32_t)cfg->boxes_info));
    } else {
        bscaler_write_reg(BSCALER_FRMC_BOX_BASE,
                          (uint32_t)nndma_ddr_vir_to_phy((uint32_t)cfg->boxes_info));
    }
#endif

#ifdef CHIP_SIM_ENV
    if ((cfg->bus >> 2) & 0x1) {//oram
        bscaler_write_reg(BSCALER_FRMC_YBASE_SRC,
                          (uint32_t)plat_va_2_pa((uint32_t)(cfg->src_base0)));
        bscaler_write_reg(BSCALER_FRMC_CBASE_SRC,
                          (uint32_t)plat_va_2_pa((uint32_t)(cfg->src_base1)));
    } else {//ddr
        bscaler_write_reg(BSCALER_FRMC_YBASE_SRC,
                          (uint32_t)plat_va_2_pa((uint32_t)(cfg->src_base0)));
        bscaler_write_reg(BSCALER_FRMC_CBASE_SRC,
                          (uint32_t)plat_va_2_pa((uint32_t)(cfg->src_base0)));
    }
    for (i = 0; i < box_num; i++) {
        if ((cfg->bus >> 3) & 0x1) {//oram
            bscaler_write_reg(BSCALER_FRMC_BASE_DST,
                              (uint32_t)plat_va_2_pa((uint32_t)cfg->dst_base[i]));
        } else {
            bscaler_write_reg(BSCALER_FRMC_BASE_DST,
                              (uint32_t)plat_va_2_pa((uint32_t)cfg->dst_base[i]));
        }
    }
    if ((cfg->bus >> 1) & 0x1) {//oram
        bscaler_write_reg(BSCALER_FRMC_BOX_BASE,
                          (uint32_t)plat_va_2_pa((uint32_t)cfg->boxes_info));
    } else {//ddr
        bscaler_write_reg(BSCALER_FRMC_BOX_BASE,
                          (uint32_t)plat_va_2_pa((uint32_t)cfg->boxes_info));
    }
#endif

    bscaler_write_reg(BSCALER_FRMC_MODE, ((src_format & 0x1) << 0 |
                                          (cfg->affine & 0x1) << 1 |
                                          (cfg->box_mode & 0x1) << 2 |
                                          (dst_format & 0x1) << 3 |
                                          (bpp_mode & 0x3) << 4 |
                                          (cfg->zero_point & 0xff) << 8 |
                                          (cfg->y_gain_exp & 0x7) << 16));
    bscaler_write_reg(BSCALER_FRMC_WH_SRC, (cfg->src_box_h << 16 |
                                            cfg->src_box_w));
    bscaler_write_reg(BSCALER_FRMC_PS_SRC, cfg->src_line_stride);
    bscaler_write_reg(BSCALER_FRMC_WH_DST, (cfg->dst_box_h << 16 |
                                            cfg->dst_box_w));
    bscaler_write_reg(BSCALER_FRMC_PS_DST, ((cfg->dst_line_stride & 0xffff) << 0));

    //fill box info
    bscaler_write_reg(BSCALER_FRMC_BOX0, (cfg->src_box_y << 16 |
                                          cfg->src_box_x) );
    bscaler_write_reg(BSCALER_FRMC_BOX1, (cfg->dst_box_y << 16 |
                                          cfg->dst_box_x) );
    bscaler_write_reg(BSCALER_FRMC_BOX2, cfg->matrix[0]);
    bscaler_write_reg(BSCALER_FRMC_BOX3, cfg->matrix[1]);
    bscaler_write_reg(BSCALER_FRMC_BOX4, cfg->matrix[2]);
    bscaler_write_reg(BSCALER_FRMC_BOX5, cfg->matrix[3]);
    bscaler_write_reg(BSCALER_FRMC_BOX6, cfg->matrix[4]);
    bscaler_write_reg(BSCALER_FRMC_BOX7, cfg->matrix[5]);
    bscaler_write_reg(BSCALER_FRMC_BOX8, cfg->matrix[6]);
    bscaler_write_reg(BSCALER_FRMC_BOX9, cfg->matrix[7]);
    bscaler_write_reg(BSCALER_FRMC_BOX10, cfg->matrix[8]);
    //fill perspective info
    bscaler_write_reg(BSCALER_FRMC_MONO, (cfg->mono_x << 0 |
                                          cfg->mono_y << 16));
    for (i = 0; i < cfg->dst_box_w; i += 4) {
        bscaler_write_reg(BSCALER_FRMC_EXTREME_Y, (cfg->extreme_point[i] << 0 |
                                                   cfg->extreme_point[i+1] << 8 |
                                                   cfg->extreme_point[i+2] << 16 |
                                                   cfg->extreme_point[i+3] << 24));
    }

    bscaler_write_reg(BSCALER_FRMC_ISUM, 0); //clear summary
    bscaler_write_reg(BSCALER_FRMC_OSUM, 0); //clear summary
    bscaler_write_reg(BSCALER_FRMC_CTRL, cfg->irq_mask << 6 | 1 << 0);
}

void bscaler_frmt_write_chain(uint32_t reg, uint32_t val, uint32_t *addr, uint32_t tm)
{
    *addr = val;
    *(addr+1) = (tm << 31) | reg;
}

uint32_t bscaler_frmt_cfg_chain(bst_hw_once_cfg_s *pre,
                                bst_hw_once_cfg_s *cur, uint32_t *addr)
{
#if 0 //add by jmqi, need recode
    uint32_t chain_len = 0;
    if (pre->src_base0 != cur->src_base0) {
        bscaler_frmt_write_chain(BSCALER_SRC_BASE0, cur->src_base0, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->src_base1 != cur->src_base1) {
        bscaler_frmt_write_chain(BSCALER_SRC_BASE1, cur->src_base1, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->src_h != cur->src_h ||
        pre->src_w != cur->src_w) {
        bscaler_frmt_write_chain(BSCALER_FRMT_WH_SRC, (cur->src_h << 16 |
                                                       cur->src_w), addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->src_line_stride != cur->src_line_stride) {
        bscaler_frmt_write_chain(BSCALER_SRC_LINE_STRIDE, cur->src_line_stride, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->dst_base0 != cur->dst_base0) {
        bscaler_frmt_write_chain(BSCALER_DST_BASE0, cur->dst_base0, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->dst_base1 != cur->dst_base1) {
        bscaler_frmt_write_chain(BSCALER_DST_BASE1, cur->dst_base1, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->dst_line_stride != cur->dst_line_stride) {
        bscaler_frmt_write_chain(BSCALER_DST_LINE_STRIDE, cur->dst_line_stride, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    if (pre->frmt_fs_dst != cur->frmt_fs_dst) {
        bscaler_frmt_write_chain(BSCALER_FRMT_FS_DST, cur->frmt_fs_dst, addr, 0);
        addr += 2;
        chain_len += 8;
    }
    bscaler_frmt_write_chain(BSCALER_FRMT_CTRL, 1, addr, 1);
    addr +=2;
    chain_len += 8;
    {
        uint32_t back[2];
        back[0] = addr;
        back[1] = chain_len;
        return (back);
    }
#endif
}

bs_chain_ret_s bscaler_frmc_chain_cfg(bs_hw_once_cfg_s *cfg, uint32_t *addr)
{
    uint32_t chain_len =0;
    uint32_t i;
    uint32_t box_num;
    uint32_t src_format = cfg->src_format & 0x1;
    uint32_t dst_format = cfg->dst_format & 0x1;
    uint32_t bpp_mode = (cfg->src_format >> 5) & 0x3;
	bs_chain_ret_s ret;
    if (!dst_format)
        box_num = 2;
    else
        box_num = cfg->box_num;
#ifdef EYER_SIM_ENV
    bscaler_frmc_write_chain(BSCALER_FRMC_YBASE_SRC, (uint32_t)(cfg->src_base0), addr, 0);
    addr +=2;
    chain_len +=8;
    bscaler_frmc_write_chain(BSCALER_FRMC_CBASE_SRC, (uint32_t)(cfg->src_base1), addr, 0);
    addr +=2;
    chain_len +=8;

    for(i=0;i<box_num;i++){
        bscaler_frmc_write_chain(BSCALER_FRMC_BASE_DST, (uint32_t)cfg->dst_base[i], addr, 0);
        addr +=2;
        chain_len +=8;
    }

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX_BASE, (uint32_t)cfg->boxes_info, addr, 0);

    addr +=2;
    chain_len +=8;
#endif

#ifdef CSE_SIM_ENV
    if ((cfg->bus >> 2) & 0x1) {
        bscaler_frmc_write_chain(BSCALER_FRMC_YBASE_SRC, (unsigned int)nndma_oram_vir_to_phy(cfg->src_base0) , addr , 0);
        addr +=2;
        chain_len +=8;
        bscaler_frmc_write_chain(BSCALER_FRMC_CBASE_SRC, (unsigned int)nndma_oram_vir_to_phy(cfg->src_base1) , addr , 0);
        addr +=2;
        chain_len +=8;
    } else {
        bscaler_frmc_write_chain(BSCALER_FRMC_YBASE_SRC, (unsigned int)nndma_ddr_vir_to_phy(cfg->src_base0) , addr , 0);
        addr +=2;
        chain_len +=8;
        bscaler_frmc_write_chain(BSCALER_FRMC_CBASE_SRC, (unsigned int)nndma_ddr_vir_to_phy(cfg->src_base1) , addr , 0);
        addr +=2;
        chain_len +=8;
    }
    for(i=0;i<box_num;i++){
        if((cfg->bus >> 3) & 0x1)
            bscaler_frmc_write_chain(BSCALER_FRMC_BASE_DST, (unsigned int)nndma_oram_vir_to_phy(cfg->dst_base[i]) , addr , 0);
        else
            bscaler_frmc_write_chain(BSCALER_FRMC_BASE_DST, (unsigned int)nndma_ddr_vir_to_phy(cfg->dst_base[i]) , addr , 0);
        addr +=2;
        chain_len +=8;
    }
    if ((cfg->bus >> 1) & 0x1) {
        bscaler_frmc_write_chain(BSCALER_FRMC_BOX_BASE, (unsigned int)nndma_oram_vir_to_phy(cfg->boxes_info) , addr , 0);
        addr +=2;
        chain_len +=8;
    } else {
        bscaler_frmc_write_chain(BSCALER_FRMC_BOX_BASE, (unsigned int)nndma_ddr_vir_to_phy(cfg->boxes_info) , addr , 0);
        addr +=2;
        chain_len +=8;
    }
#endif

#ifdef CHIP_SIM_ENV
    if ((cfg->bus >> 2) & 0x1) {//oram
        bscaler_frmc_write_chain(BSCALER_FRMC_YBASE_SRC, plat_va_2_pa(cfg->src_base0), addr, 0);
        addr +=2;
        chain_len +=8;
        bscaler_frmc_write_chain(BSCALER_FRMC_CBASE_SRC, plat_va_2_pa(cfg->src_base1), addr, 0);
        addr +=2;
        chain_len +=8;
    } else { //ddr
        bscaler_frmc_write_chain(BSCALER_FRMC_YBASE_SRC, plat_va_2_pa(cfg->src_base0), addr, 0);
        addr +=2;
        chain_len +=8;
        bscaler_frmc_write_chain(BSCALER_FRMC_CBASE_SRC, plat_va_2_pa(cfg->src_base1), addr , 0);
        addr +=2;
        chain_len +=8;
    }

    for (i = 0; i < box_num; i++) {
        if ((cfg->bus >> 3) & 0x1)//oram
            bscaler_frmc_write_chain(BSCALER_FRMC_BASE_DST, plat_va_2_pa(cfg->dst_base[i]), addr, 0);
        else //ddr
            bscaler_frmc_write_chain(BSCALER_FRMC_BASE_DST, plat_va_2_pa(cfg->dst_base[i]), addr, 0);
        addr +=2;
        chain_len +=8;
    }
    if ((cfg->bus >> 1) & 0x1) {//oram
        bscaler_frmc_write_chain(BSCALER_FRMC_BOX_BASE, plat_va_2_pa(cfg->boxes_info), addr, 0);
        addr += 2;
        chain_len += 8;
    } else { //ddr
        bscaler_frmc_write_chain(BSCALER_FRMC_BOX_BASE, plat_va_2_pa(cfg->boxes_info), addr, 0);
        addr +=2;
        chain_len +=8;
    }
#endif

    bscaler_frmc_write_chain(BSCALER_FRMC_MODE, ((src_format & 0x1) << 0 |
                                                 (cfg->affine & 0x1) << 1 |
                                                 (cfg->box_mode & 0x1) << 2 |
                                                 (dst_format & 0x1) << 3 |
                                                 (bpp_mode & 0x3) << 4 |
                                                 (cfg->zero_point & 0xff) << 8 |
                                                 (cfg->y_gain_exp & 0x7) << 16) , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_WH_SRC, (cfg->src_box_h << 16 |
                                                   cfg->src_box_w) , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_PS_SRC, cfg->src_line_stride , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_WH_DST, (cfg->dst_box_h << 16 |
                                                   cfg->dst_box_w) , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_PS_DST, ((cfg->dst_line_stride & 0xffff) << 0) , addr , 0);
    addr +=2;
    chain_len +=8;

    //fill box info
    bscaler_frmc_write_chain(BSCALER_FRMC_BOX0, (cfg->src_box_y << 16 |
                                                 cfg->src_box_x)  , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX1, (cfg->dst_box_y << 16 |
                                                 cfg->dst_box_x)  , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX2, cfg->matrix[0] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX3, cfg->matrix[1] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX4, cfg->matrix[2] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX5, cfg->matrix[3] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX6, cfg->matrix[4] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX7, cfg->matrix[5] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX8, cfg->matrix[6] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX9, cfg->matrix[7] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_BOX10, cfg->matrix[8] , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_MONO, (cfg->mono_x << 0 |
                                                 cfg->mono_y << 16), addr , 0);
    addr +=2;
    chain_len +=8;

    for (i = 0; i < cfg->dst_box_w; i += 4) {
        bscaler_frmc_write_chain(BSCALER_FRMC_EXTREME_Y, (cfg->extreme_point[i] << 0 |
                                                          cfg->extreme_point[i+1] << 8 |
                                                          cfg->extreme_point[i+2] << 16 |
														  cfg->extreme_point[i+3] << 24), addr, 0);
        addr +=2;
        chain_len +=8;
    }

    bscaler_frmc_write_chain(BSCALER_FRMC_BUS, cfg->bus , addr , 0);
    addr +=2;
    chain_len +=8;

    bscaler_frmc_write_chain(BSCALER_FRMC_CTRL, cfg->irq_mask << 6 | 1<<0 , addr , 1);
    addr +=2;
    chain_len +=8;

	{
        ret.bs_ret_base = addr;
        ret.bs_ret_len = chain_len;
        return (ret);
	}
}

void bsc_chain_hw_cfg(bs_chain_cfg_s cfg)
{
#ifdef EYER_SIM_ENV	
	bscaler_write_reg(BSCALER_FRMC_CHAIN_BASE, (uint32_t)cfg.bs_chain_base);
#endif
#ifdef CSE_SIM_ENV
    if ((cfg->bus >> 0) & 0x1) {//oram
		bscaler_write_reg(BSCALER_FRMC_CHAIN_BASE, (uint32_t)nndma_oram_vir_to_phy((uint32_t)(cfg.bs_chain_base)));
	}
	else{
		bscaler_write_reg(BSCALER_FRMC_CHAIN_BASE, (uint32_t)nndma_ddr_vir_to_phy((uint32_t)(cfg.bs_chain_base)));
	}
#endif

	bscaler_write_reg(BSCALER_FRMC_CHAIN_LEN, cfg.bs_chain_len);
	bscaler_write_reg(BSCALER_FRMC_CHAIN_CTRL,cfg.bs_chain_irq<<3 | 1<<0);//start hw


}
