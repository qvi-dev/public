
extern int oram_memory_init (void *mp, unsigned int mp_size);

extern void oram_memory_deinit (void);

extern void *oram_malloc (unsigned int size);

extern void oram_free (void *addr);

extern void *oram_calloc (unsigned int size, unsigned int n);

extern void *oram_realloc (void *addr, unsigned int size);

extern void *oram_memalign (unsigned int align, unsigned int size);

