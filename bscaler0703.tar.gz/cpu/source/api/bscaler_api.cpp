/*
 *        (C) COPYRIGHT Ingenic Limited.
 *             ALL RIGHTS RESERVED
 *
 * File       : bscaler_api.cpp
 * Authors    : jmqi@taurus
 * Create Time: 2020-04-20:09:29:03
 * Description:
 *
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <vector>
#include <string.h>

#include "matrix.h"
#include "bscaler_hw_api.h"
#include "bscaler_api.h"
#include "bscaler_mdl.h"

#ifndef RELEASE
#include "AutoTime.hpp"//for statistics run time
#endif

#define DST_MAX_WIDTH           (8192)
uint32_t *bsc_chain_base = NULL;
uint32_t *bst_chain_base = NULL;

enum MONO {
    INCREASE            = 0,
    DECREASE            = 1,
};

/**
 * get scale up exponent
 */
static inline uint32_t get_exp(float scale_y)
{
    uint32_t n = 1;
    while ((scale_y * (1 << n)) < 1.0f) {
        n++;
    }
    return n;
}

static inline void matrix_s32_dump(int32_t *matrix)
{
    printf("Matrix S32:\n");
    printf("%d, %d, %d\n", matrix[0], matrix[1], matrix[2]);
    printf("%d, %d, %d\n", matrix[3], matrix[4], matrix[5]);
    printf("%d, %d, %d\n", matrix[6], matrix[7], matrix[8]);
}

static inline void matrix_f32_dump(float *matrix)
{
    printf("Matrix F32:\n");
    printf("%f, %f, %f\n", matrix[0], matrix[1], matrix[2]);
    printf("%f, %f, %f\n", matrix[3], matrix[4], matrix[5]);
    printf("%f, %f, %f\n", matrix[6], matrix[7], matrix[8]);
}

/**
 * caculate source sub-box base on destionation box,
 * affine matrix, and source whole box
 */
static inline void affine_cac_sub_box(box_info_s *src, box_info_s *dst,
                                      int32_t *matrix, box_info_s *wbox)
{
    int dst_x0 = dst->x;
    int dst_y0 = dst->y;
    int dst_x1 = dst->x + dst->w - 1;
    int dst_y1 = dst->y;
    int dst_x2 = dst->x;
    int dst_y2 = dst->y + dst->h - 1;
    int dst_x3 = dst->x + dst->w - 1;
    int dst_y3 = dst->y + dst->h - 1;

    int64_t src_x0 = (int64_t)matrix[MSCALEX] * dst_x0 + (int64_t)matrix[MSKEWX] * dst_y0 + matrix[MTRANSX];
    int64_t src_y0 = (int64_t)matrix[MSKEWY] * dst_x0 + (int64_t)matrix[MSCALEY] * dst_y0 + matrix[MTRANSY];

    int64_t src_x1 = (int64_t)matrix[MSCALEX] * dst_x1 + (int64_t)matrix[MSKEWX] * dst_y1 + matrix[MTRANSX];
    int64_t src_y1 = (int64_t)matrix[MSKEWY] * dst_x1 + (int64_t)matrix[MSCALEY] * dst_y1 + matrix[MTRANSY];

    int64_t src_x2 = (int64_t)matrix[MSCALEX] * dst_x2 + (int64_t)matrix[MSKEWX] * dst_y2 + matrix[MTRANSX];
    int64_t src_y2 = (int64_t)matrix[MSKEWY] * dst_x2 + (int64_t)matrix[MSCALEY] * dst_y2 + matrix[MTRANSY];

    int64_t src_x3 = (int64_t)matrix[MSCALEX] * dst_x3 + (int64_t)matrix[MSKEWX] * dst_y3 + matrix[MTRANSX];
    int64_t src_y3 = (int64_t)matrix[MSKEWY] * dst_x3 + (int64_t)matrix[MSCALEY] * dst_y3 + matrix[MTRANSY];

    src_x0 = CLIP(src_x0 >> MAT_ACC, 0, S32_MAX);
    src_y0 = CLIP(src_y0 >> MAT_ACC, 0, S32_MAX);
    src_x1 = CLIP(src_x1 >> MAT_ACC, 0, S32_MAX);
    src_y1 = CLIP(src_y1 >> MAT_ACC, 0, S32_MAX);
    src_x2 = CLIP(src_x2 >> MAT_ACC, 0, S32_MAX);
    src_y2 = CLIP(src_y2 >> MAT_ACC, 0, S32_MAX);
    src_x3 = CLIP(src_x3 >> MAT_ACC, 0, S32_MAX);
    src_y3 = CLIP(src_y3 >> MAT_ACC, 0, S32_MAX);

    int32_t max_x01 = MAX(src_x0, src_x1);
    int32_t max_x23 = MAX(src_x2, src_x3);
    int32_t max_x = MAX(max_x01, max_x23);

    int32_t min_x01 = MIN(src_x0, src_x1);
    int32_t min_x23 = MIN(src_x2, src_x3);
    int32_t min_x = MIN(min_x01, min_x23);

    int32_t max_y01 = MAX(src_y0, src_y1);
    int32_t max_y23 = MAX(src_y2, src_y3);
    int32_t max_y = MAX(max_y01, max_y23);

    int32_t min_y01 = MIN(src_y0, src_y1);
    int32_t min_y23 = MIN(src_y2, src_y3);
    int32_t min_y = MIN(min_y01, min_y23);

    int src_box_w = wbox->w - 1;
    int src_box_h = wbox->h - 1;
    min_x = CLIP(min_x, 0, src_box_w);
    max_x = CLIP(max_x + 1, 0, src_box_w);
    min_y = CLIP(min_y, 0, src_box_h);
    max_y = CLIP(max_y + 1, 0, src_box_h);

	/* src->x = min_x;
    src->y = min_y;
    src->w = max_x - src->x + 1;
    src->h = max_y - src->y + 1;*/

    src->x = ((int)min_x) % 2 ? (int)min_x - 1 : (int)min_x;
    src->y = ((int)min_y) % 2 ? (int)min_y - 1 : (int)min_y;
    src->w = (int)ceilf(max_x) - src->x + 1;
    src->h = (int)ceilf(max_y) - src->y + 1;
	if (src->w % 2) {
		src->w++;
	}

	if (src->h % 2) {
		src->h++;
	}

}

/**
 * caculate source sub-box base on destionation box,
 * perspective matrix, and source whole box
 */
static inline void perspective_cac_sub_box(box_info_s *src, box_info_s *dst,
                                           int32_t *matrix, box_info_s *wbox)
{
#ifndef RELEASE
    //AUTOTIME;
#endif

#if 0
    int src_box_w = wbox->w - 1;
    int src_box_h = wbox->h - 1;
    int16_t min_x = wbox->w - 1;
    int16_t min_y = wbox->h - 1;
    int16_t max_x = 0;
    int16_t max_y = 0;
    int cnt = 0;
    printf("dst box : %d, %d, %d, %d\n", dst->x, dst->y, dst->w, dst->h);

    //efficiency is too low, must improve!!!! fixme
    for (int dy = dst->y; dy < dst->y + dst->h; dy++) {
        //for (int dx = dst->x; dx < dst->x + dst->w; dx++) {
        //int delta_dx = ((dy == dst->y) || (dy == dst->y + dst->h - 1)) ? 1 :
        //    dst->w - 1;
        int delta_dx = 1;
        //if ((dst->x == 0) && (dst->y == 0)) {
        //    printf("dy=%d, delta_dx=%d\n", dy, delta_dx);
        //}

        for (int dx = dst->x; dx < dst->x + dst->w; dx += delta_dx) {
            int64_t sx_s64 = ((int64_t)matrix[0] * dx +
                              (int64_t)matrix[1] * dy + matrix[2]);
            int64_t sy_s64 = ((int64_t)matrix[3] * dx +
                              (int64_t)matrix[4] * dy + matrix[5]);
            int64_t sz_s64 = ((int64_t)matrix[6] * dx +
                              (int64_t)matrix[7] * dy + matrix[8]);
            int32_t sx_p = 0, sy_p = 0;
            if (sz_s64) {
                int64_t sx_s64_final = sx_s64 * (1 << MAT_ACC) / sz_s64;
                int64_t sy_s64_final = sy_s64 * (1 << MAT_ACC) / sz_s64;
                int32_t sx_s32_clip = CLIP(sx_s64_final, INT_MIN, INT_MAX);
                int32_t sy_s32_clip = CLIP(sy_s64_final, INT_MIN, INT_MAX);
                sx_p = sx_s32_clip >> MAT_ACC;
                sy_p = sy_s32_clip >> MAT_ACC;
            }
            //if ((dst->x == 0) && (dst->y == 0)) {
            //    printf("(%d,%d) -- (%d,%d)\n", dx, dy, sx_p, sy_p);
            //}

            //sx_p = CLIP(sx_p, 0, src_box_w);
            //sy_p = CLIP(sy_p, 0, src_box_h);
            if (((sx_p >= 0) && (sx_p < wbox->w)) &&
                ((sy_p >= 0) && (sy_p < wbox->h))) {
                min_x = MIN(min_x, sx_p);
                min_y = MIN(min_y, sy_p);
                max_x = MAX(max_x, sx_p + 1);
                max_y = MAX(max_y, sy_p + 1);
                //if ((dst->x == 64) && (dst->y == 0)) {
                //    printf("xxx:(%d,%d) -- (%d,%d) (%d,%d)(%d,%d)\n", dx, dy, sx_p, sy_p, min_x, min_y, max_x, max_y);
                //}
                cnt++;
            }
        }
    }
    min_x = CLIP(min_x, 0, src_box_w);
    max_x = CLIP(max_x, 0, src_box_w);
    min_y = CLIP(min_y, 0, src_box_h);
    max_y = CLIP(max_y, 0, src_box_h);
	/* src->x = (int)min_x;
    src->y = (int)min_y;
    src->w = (int)ceilf(max_x) - src->x + 1;
    src->h = (int)ceilf(max_y) - src->y + 1;*/
    src->x = ((int)min_x) % 2 ? (int)min_x - 1 : (int)min_x;
    src->y = ((int)min_y) % 2 ? (int)min_y - 1 : (int)min_y;
    src->w = (int)ceilf(max_x) - src->x + 1;
    src->h = (int)ceilf(max_y) - src->y + 1;
	if (src->w % 2) {
		src->w++;
	}

	if (src->h % 2) {
		src->h++;
	}
    src->w = CLIP(src->w, 0, src_box_w + 1);
    src->h = CLIP(src->h, 0, src_box_h + 1);

#else//only for test
    src->x = (int)0;
    src->y = (int)0;
    src->w = (int)wbox->w;
    src->h = (int)wbox->h;
#endif
    //if ((dst->x == 0) && (dst->y == 0)) {
    //    printf("box:(%d,%d),(%d,%d)\n", src->x, src->y, src->w, src->h);
    //}
    //printf("(%d,%d)box:(%d,%d),(%d,%d)\n", dst->x, dst->y, src->x, src->y, src->w, src->h);
}

/**
 * caculate source sub-box base on destionation box,
 * resize coef, and source whole box
 */
static inline void resize_cac_sub_box(box_info_s *src, box_info_s *dst,
                                      box_info_s *wbox,
                                      float scale_x, float scale_y,
                                      float trans_x, float trans_y)
{
    float dst_x0 = dst->x;
    float dst_y0 = dst->y;
    float dst_x1 = dst->x + dst->w - 1;
    float dst_y1 = dst->y;
    float dst_x2 = dst->x;
    float dst_y2 = dst->y + dst->h - 1;
    float dst_x3 = dst->x + dst->w - 1;
    float dst_y3 = dst->y + dst->h - 1;

    float src_x0 = scale_x * dst_x0 + trans_x;
    float src_y0 = scale_y * dst_y0 + trans_y;

    float src_x1 = scale_x * dst_x1 + trans_x;
    float src_y1 = scale_y * dst_y1 + trans_y;

    float src_x2 = scale_x * dst_x2 + trans_x;
    float src_y2 = scale_y * dst_y2 + trans_y;

    float src_x3 = scale_x * dst_x3 + trans_x;
    float src_y3 = scale_y * dst_y3 + trans_y;

    float max_x01 = MAX(src_x0, src_x1);
    float max_x23 = MAX(src_x2, src_x3);
    float max_x = MAX(max_x01, max_x23);

    float min_x01 = MIN(src_x0, src_x1);
    float min_x23 = MIN(src_x2, src_x3);
    float min_x = MIN(min_x01, min_x23);

    float max_y01 = MAX(src_y0, src_y1);
    float max_y23 = MAX(src_y2, src_y3);
    float max_y = MAX(max_y01, max_y23);

    float min_y01 = MIN(src_y0, src_y1);
    float min_y23 = MIN(src_y2, src_y3);
    float min_y = MIN(min_y01, min_y23);

    int src_box_w = wbox->w - 1;
    int src_box_h = wbox->h - 1;
    min_x = CLIP(min_x, 0, src_box_w);
    max_x = CLIP(max_x, 0, src_box_w);
    min_y = CLIP(min_y, 0, src_box_h);
    max_y = CLIP(max_y, 0, src_box_h);

    src->x = ((int)min_x) % 2 ? (int)min_x - 1 : (int)min_x;
    src->y = ((int)min_y) % 2 ? (int)min_y - 1 : (int)min_y;
    src->w = (int)ceilf(max_x) - src->x + 1;
    src->h = (int)ceilf(max_y) - src->y + 1;
	if (src->w % 2) {
		src->w++;
	}

	if (src->h % 2) {
		src->h++;
	}

}

/**
 * generate hardware once configure information
 */
static void bs_affine_cfg_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                box_affine_info_s *info,
                                const data_info_s *src, data_info_s *dst,
                                const uint32_t *coef, const uint32_t *offset)
{
    bs_hw_once_cfg_s cfg;
    box_info_s *box = &(info->box);
    uint8_t *src_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }
    cfg.src_base1 = src_base1;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;
    cfg.src_box_x = 0;
    cfg.src_box_y = 0;
    cfg.src_box_w = box->w;
    cfg.src_box_h = box->h;

    //single destination box info(size must same)
    cfg.dst_base[0] = (uint8_t *)dst->base;
    if (dst->format == BS_DATA_NV12) {
        cfg.dst_base[1] = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }
    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.dst_box_x = 0;
    cfg.dst_box_y = 0;
    cfg.dst_box_w = dst->width;
    cfg.dst_box_h = dst->height;

    cfg.affine = true;
    cfg.box_mode = true;
    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;
    float inverse[9];
    get_inverse_matrix(info->matrix, inverse);
    matrix_float_to_s32(inverse, cfg.matrix);

    cfg.y_gain_exp = 0;
    //line mode, multi-box info
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;
    bs_cfgs.push_back(cfg);
}

static void perspective_mono(int32_t *matrix,
                             int32_t *sx_mono, bool *sx_mono_increase,
                             int32_t *sy_mono, bool *sy_mono_increase)
{
    double m1xm8 = (double)matrix[1] * matrix[8];
    double m2xm7 = (double)matrix[2] * matrix[7];
    double m0xm7 = (double)matrix[0] * matrix[7];
    double m1xm6 = (double)matrix[1] * matrix[6];

    double m4xm8 = (double)matrix[4] * matrix[8];
    double m5xm7 = (double)matrix[5] * matrix[7];
    double m3xm7 = (double)matrix[3] * matrix[7];
    double m4xm6 = (double)matrix[4] * matrix[6];

    //matrix_s32_dump(matrix);

    // sx = f'(dx)
    double sxf_dx;
    if (m0xm7 - m1xm6) {
        sxf_dx = (m1xm8 - m2xm7) / (m0xm7 - m1xm6);
        *sx_mono_increase = (m1xm6 > m0xm7) ? INCREASE : DECREASE;
    } else {
        sxf_dx = -1;
        if ((m1xm8 - m2xm7) < 0) { //always decrease
            *sx_mono_increase = DECREASE;
        } else { //always increase
            *sx_mono_increase = INCREASE;
        }
    }

    // sy = f'(dx)
    double syf_dx;
    if (m3xm7 - m4xm6) {
        syf_dx = (m4xm8 - m5xm7) / (m3xm7 - m4xm6);
        *sy_mono_increase = (m4xm6 > m3xm7) ? INCREASE : DECREASE;
    } else {
        syf_dx = -1;
        if ((m4xm8 - m5xm7) < 0) {
            *sy_mono_increase = DECREASE;
        } else {
            *sy_mono_increase = INCREASE;
        }
    }

    *sx_mono = (int32_t)ceil(sxf_dx);
    *sy_mono = (int32_t)ceil(syf_dx);

    //printf("sxf_dx=%lf, syf_dx=%lf, sx_mono_increase=%d, sy_mono_increase=%d\n", sxf_dx, syf_dx, *sx_mono_increase, *sy_mono_increase);
}

/**
 * generate hardware once configure information
 */
static void bs_perspective_cfg_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                     box_affine_info_s *info,
                                     const data_info_s *src, data_info_s *dst,
                                     const uint32_t *coef, const uint32_t *offset)
{
    bs_hw_once_cfg_s cfg;
    box_info_s *box = &(info->box);
    uint8_t *src_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }
    cfg.src_base1 = src_base1;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;
    cfg.src_box_x = 0;
    cfg.src_box_y = 0;
    cfg.src_box_w = box->w;
    cfg.src_box_h = box->h;

    //single destination box info(size must same)
    cfg.dst_base[0] = (uint8_t *)dst->base;
    if (dst->format == BS_DATA_NV12) {
        cfg.dst_base[1] = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }
    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.dst_box_x = 0;
    cfg.dst_box_y = 0;
    cfg.dst_box_w = dst->width;
    cfg.dst_box_h = dst->height;

    cfg.affine = true;
    cfg.box_mode = true;
    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;
    float inverse[9];
    get_inverse_matrix(info->matrix, inverse);
    matrix_float_to_s32(inverse, cfg.matrix);
    int32_t mono_x_ep, mono_y_ep;//extreme_point
    bool mono_sx, mono_sy;
    perspective_mono(cfg.matrix, &mono_x_ep, &mono_sx, &mono_y_ep, &mono_sy);
    if (mono_x_ep > 64) {
        cfg.mono_x = (mono_sx << 7) | 64;
    } else if (mono_x_ep < 0) {
        cfg.mono_x = (mono_sx << 7) | 0;
    } else {
        cfg.mono_x = (mono_sx << 7) | mono_x_ep;
    }

    if (mono_y_ep > 64) {
        cfg.mono_y = (mono_sy << 7) | 64;
    } else if (mono_y_ep < 0) {
        cfg.mono_y = (mono_sy << 7) | 0;
    } else {
        cfg.mono_y = (mono_sy << 7) | mono_y_ep;
    }

    for (int dx = 0; dx < dst->width; dx++) {
        double act_extreme_point = -((double)dx * cfg.matrix[6] + cfg.matrix[8])/ cfg.matrix[7];
        int act_extreme_point_s32 = act_extreme_point;
        if (mono_sy == INCREASE) {
            if (dx > mono_y_ep) {
                act_extreme_point_s32 += 1;
            }
        } else {
            if (dx < mono_y_ep) {
                act_extreme_point_s32 += 1;
            }
        }
        cfg.extreme_point[dx] = (int8_t)(act_extreme_point_s32 < 0 ? -1 :
                                         act_extreme_point_s32 > (dst->height - 1) ? 64 :
                                         act_extreme_point_s32);
    }

    cfg.y_gain_exp = 0;
    //line mode, multi-box info
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;
    bs_cfgs.push_back(cfg);
}

/**
 * user configure affine mode but it's can used resize
 */
static void bs_affine_resize_cfg_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                       box_affine_info_s *info,
                                       const data_info_s *src, data_info_s *dst,
                                       const uint32_t *coef, const uint32_t *offset)
{
    bs_hw_once_cfg_s cfg;
    box_info_s *box = &(info->box);
    uint8_t *src_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    cfg.src_base1 = src_base1;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;
    cfg.src_box_x = 0;
    cfg.src_box_y = 0;
    cfg.src_box_w = box->w;
    cfg.src_box_h = box->h;

    //single destination box info(size must same)
    cfg.dst_base[0] = (uint8_t *)dst->base;
    if (dst->format == BS_DATA_NV12) {
        cfg.dst_base[1] = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }
    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.dst_box_x = 0;
    cfg.dst_box_y = 0;
    cfg.dst_box_w = dst->width;
    cfg.dst_box_h = dst->height;

    cfg.affine = false;
    cfg.box_mode = true;
    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;//fixme

    float scale_x = info->matrix[MSCALEX];
    float scale_y = info->matrix[MSCALEY];
    float trans_x = info->matrix[MTRANSX];
    float trans_y = info->matrix[MTRANSY];

    float inverse_scale_x = scale_x ? (1 / scale_x) : 0;
    float inverse_trans_x = trans_x ? (1 / trans_x) : 0;
    float inverse_scale_y = scale_y ? (1 / scale_y) : 0;
    float inverse_trans_y = trans_y ? (1 / trans_y) : 0;

    cfg.matrix[MSCALEX] = (int32_t)round(inverse_scale_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWX] = 0;
    cfg.matrix[MTRANSX] = (int32_t)round(inverse_trans_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWY] = 0;
    cfg.matrix[MSCALEY] = (int32_t)round(inverse_scale_y * (1 << MAT_ACC));
    cfg.matrix[MTRANSY] = (int32_t)round(inverse_trans_y * (1 << MAT_ACC));
    cfg.matrix[MPERSP0] = 0;
    cfg.matrix[MPERSP1] = 0;
    cfg.matrix[MPERSP2] = 0;

    cfg.y_gain_exp = 0;
    //line mode, multi-box info
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;
    bs_cfgs.push_back(cfg);
}

/**
 * affine mode, but hardware can not do it directly, must do it separately
 */
static void affine_box_split(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                             box_affine_info_s *info,
                             const data_info_s *src, data_info_s *dst,
                             const uint32_t *coef, const uint32_t *offset)
{
    box_info_s *box = &(info->box);

    /* 1. caculate source whole-box base address */
    uint8_t *src_wbox_base0 = NULL;
    uint8_t *src_wbox_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_wbox_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    /* 2. caculate source whole-box base address */
    uint8_t *dst_wbox_base0 = (uint8_t *)(dst->base);
    uint8_t *dst_wbox_base1 = NULL;
    if (dst->format == BS_DATA_NV12) {
        dst_wbox_base1 = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }

    /* 3. caculate destination/source sub-box information */
    float inverse[9];
    get_inverse_matrix(info->matrix, inverse);
    int32_t matrix_s32[9];
    matrix_float_to_s32(inverse, matrix_s32);

    const int sbox_num_w = (dst->width + BS_AFFINE_SIZE - 1) / BS_AFFINE_SIZE;
    const int sbox_num_h = (dst->height + BS_AFFINE_SIZE - 1) / BS_AFFINE_SIZE;
    int sbox_num = sbox_num_w * sbox_num_h;
    // caculate dst sub-box information
    box_info_s *dst_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (dst_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }
    int i, j;
    for (j = 0; j < sbox_num_h; j++) {
        for (i = 0; i < sbox_num_w; i++) {
            dst_sbox[j * sbox_num_w + i].x = i * BS_AFFINE_SIZE;
            dst_sbox[j * sbox_num_w + i].y = j * BS_AFFINE_SIZE;
            int sbox_w = (i == (sbox_num_w - 1)) ?
                (dst->width - 1) % BS_AFFINE_SIZE + 1 : BS_AFFINE_SIZE;
            int sbox_h = (j == (sbox_num_h - 1)) ?
                (dst->height - 1) % BS_AFFINE_SIZE + 1 : BS_AFFINE_SIZE;
            dst_sbox[j * sbox_num_w + i].w = sbox_w;
            dst_sbox[j * sbox_num_w + i].h = sbox_h;
        }
    }
    // caculate src sub-box information
    box_info_s *src_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (src_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    box_info_s wbox = {0, 0, box->w, box->h};
    for (int i = 0; i < sbox_num; i++) {
        affine_cac_sub_box(src_sbox + i, dst_sbox + i, matrix_s32, &wbox);
    }

    /* 4. most members of each sub-box are the same,
       only sub-box x,y,w,h are different. */
    bs_hw_once_cfg_s cfg;
    memcpy(cfg.matrix, matrix_s32, sizeof(int32_t) * 9);

    cfg.y_gain_exp = 0;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;

    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.affine = true;
    cfg.box_mode = true;

    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }

    cfg.zero_point = info->zero_point;
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;

    for (int i = 0; i < sbox_num; i++) {
        uint8_t *src_sbox_base0 = NULL;
        uint8_t *src_sbox_base1 = NULL;
        if (src->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x;
            src_sbox_base1 = src_wbox_base0 + src->height * src->line_stride +
                src_sbox[i].y / 2 * src->line_stride + src_sbox[i].x;
        } else if(src->format == BS_DATA_FMU2) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 8;
        } else if(src->format == BS_DATA_FMU4) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 16;
        } else if(src->format == BS_DATA_FMU8) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 32;
        } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 4;
        }

        cfg.src_base0 = src_sbox_base0;
        cfg.src_base1 = src_sbox_base1;

        cfg.src_box_x = src_sbox[i].x;
        cfg.src_box_y = src_sbox[i].y;
        cfg.src_box_w = src_sbox[i].w;
        cfg.src_box_h = src_sbox[i].h;

        uint8_t *dst_sbox_base0 = NULL;
        uint8_t *dst_sbox_base1 = NULL;
        if (dst->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x;
            dst_sbox_base1 = dst_wbox_base0 + dst->height * dst->line_stride +
                dst_sbox[i].y / 2 * dst->line_stride + dst_sbox[i].x;
        } else if(dst->format == BS_DATA_FMU2) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 8;
        } else if(dst->format == BS_DATA_FMU4) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 16;
        } else if(dst->format == BS_DATA_FMU8) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 32;
        } else if (dst->format & 0x1) {//RGBA,ARGB, BRGA....
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 4;
        }

        cfg.dst_base[0] = dst_sbox_base0;
        cfg.dst_base[1] = dst_sbox_base1;
        cfg.dst_box_x = dst_sbox[i].x;
        cfg.dst_box_y = dst_sbox[i].y;
        cfg.dst_box_w = dst_sbox[i].w;
        cfg.dst_box_h = dst_sbox[i].h;
        bs_cfgs.push_back(cfg);
    }
    free(dst_sbox);
    free(src_sbox);
}

/**
 * perspective mode, but hardware can not do it directly, must do it separately
 */
static void perspective_box_split(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                  box_affine_info_s *info,
                                  const data_info_s *src, data_info_s *dst,
                                  const uint32_t *coef, const uint32_t *offset)
{
#ifndef RELEASE
    AUTOTIME;
#endif
    box_info_s *box = &(info->box);

    /* 1. caculate source whole-box base address */
    uint8_t *src_wbox_base0 = NULL;
    uint8_t *src_wbox_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_wbox_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    /* 2. caculate source whole-box base address */
    uint8_t *dst_wbox_base0 = (uint8_t *)(dst->base);
    uint8_t *dst_wbox_base1 = NULL;
    if (dst->format == BS_DATA_NV12) {
        dst_wbox_base1 = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }

    /* 3. caculate destination/source sub-box information */
    float inverse[9];
    get_inverse_matrix(info->matrix, inverse);
    int32_t matrix_s32[9];
    matrix_float_to_s32(inverse, matrix_s32);

    const int sbox_num_w = (dst->width + BS_AFFINE_SIZE - 1) / BS_AFFINE_SIZE;
    const int sbox_num_h = (dst->height + BS_AFFINE_SIZE - 1) / BS_AFFINE_SIZE;
    int sbox_num = sbox_num_w * sbox_num_h;
    // caculate dst sub-box information
    box_info_s *dst_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (dst_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }
    int i, j;
    for (j = 0; j < sbox_num_h; j++) {
        for (i = 0; i < sbox_num_w; i++) {
            dst_sbox[j * sbox_num_w + i].x = i * BS_AFFINE_SIZE;
            dst_sbox[j * sbox_num_w + i].y = j * BS_AFFINE_SIZE;
            int sbox_w = (i == (sbox_num_w - 1)) ?
                (dst->width - 1) % BS_AFFINE_SIZE + 1 : BS_AFFINE_SIZE;
            int sbox_h = (j == (sbox_num_h - 1)) ?
                (dst->height - 1) % BS_AFFINE_SIZE + 1 : BS_AFFINE_SIZE;
            dst_sbox[j * sbox_num_w + i].w = sbox_w;
            dst_sbox[j * sbox_num_w + i].h = sbox_h;
        }
    }
    // caculate src sub-box information
    box_info_s *src_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (src_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    box_info_s wbox = {0, 0, box->w, box->h};
    for (int i = 0; i < sbox_num; i++) {
        perspective_cac_sub_box(src_sbox + i, dst_sbox + i, matrix_s32, &wbox);
    }

    /* 4. most members of each sub-box are the same,
       only sub-box x,y,w,h are different. */
    bs_hw_once_cfg_s cfg;
    matrix_float_to_s32(inverse, cfg.matrix);

    int32_t mono_x_ep, mono_y_ep;
    bool mono_sx, mono_sy;
    perspective_mono(cfg.matrix, &mono_x_ep, &mono_sx, &mono_y_ep, &mono_sy);

    cfg.y_gain_exp = 0;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;

    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.affine = true;
    cfg.box_mode = true;

    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }

    cfg.zero_point = info->zero_point;
    double extreme_point[DST_MAX_WIDTH];
    assert(dst->width < DST_MAX_WIDTH);
    double m6_div_m7 = 0;
    double m8_div_m7 = 0;
    if (cfg.matrix[7]) {
        m6_div_m7 = cfg.matrix[6] / cfg.matrix[7];
        m8_div_m7 = cfg.matrix[8] / cfg.matrix[7];
    }

    for (int i = 0; i < dst->width; i++) {
        extreme_point[i] = -((double)i * cfg.matrix[6] / cfg.matrix[7]) - ((double)cfg.matrix[8] / cfg.matrix[7]);
    }
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;

    for (int i = 0; i < sbox_num; i++) {
        if (mono_x_ep > (dst_sbox[i].x + dst_sbox[i].w)) {
            cfg.mono_x = (mono_sx << 7) | 64;
        } else if (mono_x_ep <= dst_sbox[i].x) {
            cfg.mono_x = (mono_sx << 7) | 0;
        } else {
            cfg.mono_x = (mono_sx << 7) | (mono_x_ep - dst_sbox[i].x);
        }

        if (mono_y_ep > (dst_sbox[i].x + dst_sbox[i].w)) {
            cfg.mono_y = (mono_sy << 7) | 64;
        } else if (mono_y_ep <= dst_sbox[i].x) {
            cfg.mono_y = (mono_sy << 7) | 0;
        } else {
            cfg.mono_y = (mono_sy << 7) | (mono_y_ep - dst_sbox[i].x);
        }

        for (int dx = 0; dx < dst_sbox[i].w; dx++) {
            double act_extreme_point = extreme_point[(dx + dst_sbox[i].x)];
            int act_extreme_point_s32 = act_extreme_point;

            if (!IS_ZERO(act_extreme_point - act_extreme_point_s32)) {
                if (mono_sy == INCREASE) {
                    if ((dx + dst_sbox[i].x) > mono_y_ep) {
                        act_extreme_point_s32 += 1;
                    }
                } else {
                    if ((dx + dst_sbox[i].x) < mono_y_ep) {
                        act_extreme_point_s32 += 1;
                    }
                }
            }

            cfg.extreme_point[dx] = (int8_t)(act_extreme_point_s32 < dst_sbox[i].y ? -1 :
                                             act_extreme_point_s32 > (dst_sbox[i].y + dst_sbox[i].h - 1) ? 64 :
                                             act_extreme_point_s32 - dst_sbox[i].y);
        }

        uint8_t *src_sbox_base0 = NULL;
        uint8_t *src_sbox_base1 = NULL;
        if (src->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x;
            src_sbox_base1 = src_wbox_base0 + src->height * src->line_stride +
                src_sbox[i].y / 2 * src->line_stride + src_sbox[i].x;
        } else if(src->format == BS_DATA_FMU2) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 8;
        } else if(src->format == BS_DATA_FMU4) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 16;
        } else if(src->format == BS_DATA_FMU8) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 32;
        } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 4;
        }

        cfg.src_base0 = src_sbox_base0;
        cfg.src_base1 = src_sbox_base1;

        cfg.src_box_x = src_sbox[i].x;
        cfg.src_box_y = src_sbox[i].y;
        cfg.src_box_w = src_sbox[i].w;
        cfg.src_box_h = src_sbox[i].h;

        uint8_t *dst_sbox_base0 = NULL;
        uint8_t *dst_sbox_base1 = NULL;
        if (dst->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x;
            dst_sbox_base1 = dst_wbox_base0 + dst->height * dst->line_stride +
                dst_sbox[i].y / 2 * dst->line_stride + dst_sbox[i].x;
        } else if(dst->format == BS_DATA_FMU2) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 8;
        } else if(dst->format == BS_DATA_FMU4) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 16;
        } else if(dst->format == BS_DATA_FMU8) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 32;
        } else if (dst->format & 0x1) {//RGBA,ARGB, BRGA....
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 4;
        }

        cfg.dst_base[0] = dst_sbox_base0;
        cfg.dst_base[1] = dst_sbox_base1;
        cfg.dst_box_x = dst_sbox[i].x;
        cfg.dst_box_y = dst_sbox[i].y;
        cfg.dst_box_w = dst_sbox[i].w;
        cfg.dst_box_h = dst_sbox[i].h;
        bs_cfgs.push_back(cfg);
    }
    free(dst_sbox);
    free(src_sbox);
}

/**
 * user configure affine mode, but it's can used resize separately
 */
static void affine_resize_box_split(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                    box_affine_info_s *info,
                                    const data_info_s *src, data_info_s *dst,
                                    const uint32_t *coef, const uint32_t *offset)
{
    box_info_s *box = &(info->box);
    /* 1. caculate source whole-box base address */
    uint8_t *src_wbox_base0 = NULL;
    uint8_t *src_wbox_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_wbox_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    /* 2. caculate source whole-box base address */
    uint8_t *dst_wbox_base0 = (uint8_t *)(dst->base);
    uint8_t *dst_wbox_base1 = NULL;
    if (dst->format == BS_DATA_NV12) {
        dst_wbox_base1 = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }

    /* 3. caculate destination/source sub-box information */
    float inverse[9];
    get_inverse_matrix(info->matrix, inverse);

    const int sbox_num_w = (dst->width + BS_RESIZE_W - 1) / BS_RESIZE_W;
    const int sbox_num_h = (dst->height + BS_RESIZE_H - 1) / BS_RESIZE_H;
    int sbox_num = sbox_num_w * sbox_num_h;
    // caculate dst sub-box information
    box_info_s *dst_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (dst_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    int i, j;
    for (j = 0; j < sbox_num_h; j++) {
        for (i = 0; i < sbox_num_w; i++) {
            dst_sbox[j * sbox_num_w + i].x = i * BS_RESIZE_W;
            dst_sbox[j * sbox_num_w + i].y = j * BS_RESIZE_H;
            int sbox_w = (i == (sbox_num_w - 1)) ?
                (dst->width - 1) % BS_RESIZE_W + 1 : BS_RESIZE_W;
            int sbox_h = (j == (sbox_num_h - 1)) ?
                (dst->height - 1) % BS_RESIZE_H + 1 : BS_RESIZE_H;
            dst_sbox[j * sbox_num_w + i].w = sbox_w;
            dst_sbox[j * sbox_num_w + i].h = sbox_h;
        }
    }

    // caculate src sub-box information
    box_info_s *src_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (src_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    int32_t matrix_s32[9];
    matrix_float_to_s32(inverse, matrix_s32);
    box_info_s wbox = {0, 0, box->w, box->h};
    for (int i = 0; i < sbox_num; i++) {
        affine_cac_sub_box(src_sbox + i, dst_sbox + i, matrix_s32, &wbox);
    }

    /* 4. caculate inverse matrix scale up exponent */
    // must after cac_sub_box !!!
    uint8_t y_gain_exp = 0;
    if (fabs(inverse[MSCALEY]) < 1.0f) {// condition maybe error!!!//fixme
        y_gain_exp = get_exp(fabs(inverse[MSCALEY]));
        assert((y_gain_exp > 0) && (y_gain_exp <= 6));
        inverse[MSKEWY] *= (1 << y_gain_exp);
        inverse[MSCALEY] *= (1 << y_gain_exp);
        inverse[MTRANSY] *= (1 << y_gain_exp);
    }

    /* 5. most members of each sub-box are the same,
       only sub-box x,y,w,h are different. */
    bs_hw_once_cfg_s cfg;
    for (int i = 0; i < 6; i++) {
        cfg.matrix[i] = (int32_t)round(inverse[i] * (1 << MAT_ACC));
    }

    cfg.y_gain_exp = y_gain_exp;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;

    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.affine = false;
    cfg.box_mode = true;

    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;

    for (int i = 0; i < sbox_num; i++) {
        uint8_t *src_sbox_base0 = NULL;
        uint8_t *src_sbox_base1 = NULL;
        if (src->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x;
            src_sbox_base1 = src_wbox_base0 + src->height * src->line_stride +
                src_sbox[i].y / 2 * src->line_stride + src_sbox[i].x;
        } else if(src->format == BS_DATA_FMU2) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 8;
        } else if(src->format == BS_DATA_FMU4) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 16;
        } else if(src->format == BS_DATA_FMU8) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 32;
        } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 4;
        }

        cfg.src_base0 = src_sbox_base0;
        cfg.src_base1 = src_sbox_base1;

        cfg.src_box_x = src_sbox[i].x;
        cfg.src_box_y = src_sbox[i].y;
        cfg.src_box_w = src_sbox[i].w;
        cfg.src_box_h = src_sbox[i].h;

        uint8_t *dst_sbox_base0 = NULL;
        uint8_t *dst_sbox_base1 = NULL;
        if (dst->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x;
            dst_sbox_base1 = dst_wbox_base0 + dst->height * dst->line_stride +
                dst_sbox[i].y / 2 * dst->line_stride + dst_sbox[i].x;
        } else if(dst->format == BS_DATA_FMU2) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 8;
        } else if(dst->format == BS_DATA_FMU4) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 16;
        } else if(dst->format == BS_DATA_FMU8) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 32;
        } else if (dst->format & 0x1) {//RGBA,ARGB, BRGA....
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 4;
        }

        cfg.dst_base[0] = dst_sbox_base0;
        cfg.dst_base[1] = dst_sbox_base1;
        cfg.dst_box_x = dst_sbox[i].x;
        cfg.dst_box_y = dst_sbox[i].y;
        cfg.dst_box_w = dst_sbox[i].w;
        cfg.dst_box_h = dst_sbox[i].h;
        bs_cfgs.push_back(cfg);
    }
    free(dst_sbox);
    free(src_sbox);
}

static void bs_resize_cfg_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                const box_resize_info_s *info,
                                const data_info_s *src, const data_info_s *dst,
                                const uint32_t *coef, const uint32_t *offset)
{
    bs_hw_once_cfg_s cfg;
    const box_info_s *box = &(info->box);
    uint8_t *src_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        cfg.src_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    cfg.src_base1 = src_base1;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;
    cfg.src_box_x = 0;
    cfg.src_box_y = 0;
    cfg.src_box_w = box->w;
    cfg.src_box_h = box->h;

    //single destination box info(size must same)
    cfg.dst_base[0] = (uint8_t *)dst->base;
    if (dst->format == BS_DATA_NV12) {
        cfg.dst_base[1] = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }
    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.dst_box_x = 0;
    cfg.dst_box_y = 0;
    cfg.dst_box_w = dst->width;
    cfg.dst_box_h = dst->height;

    cfg.affine = false;
    cfg.box_mode = true;
    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;

    float scale_x = (float)box->w / (float)dst->width;
    float scale_y = (float)box->h / (float)dst->height;
    float trans_x = 0.5f;
    float trans_y = 0.5f;
    uint8_t y_gain_exp = 0;
    if (fabs(scale_y) < 1.0f) {// condition maybe error!!!//fixme
        y_gain_exp = get_exp(fabs(scale_y));
        assert(y_gain_exp > 0);
        scale_y *= (1 << y_gain_exp);
        trans_y *= (1 << y_gain_exp);
    }
    cfg.matrix[MSCALEX] = (int32_t)round(scale_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWX] = 0;
    cfg.matrix[MTRANSX] = (int32_t)round(trans_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWY] = 0;
    cfg.matrix[MSCALEY] = (int32_t)round(scale_y * (1 << MAT_ACC));
    cfg.matrix[MTRANSY] = (int32_t)round(trans_y * (1 << MAT_ACC));

    cfg.y_gain_exp = y_gain_exp;
    //line mode, multi-box info
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;
    bs_cfgs.push_back(cfg);
}

static void resize_box_split(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                             const box_resize_info_s *info,
                             const data_info_s *src, const data_info_s *dst,
                             const uint32_t *coef, const uint32_t *offset)
{
    const box_info_s *box = &(info->box);
    /* 1. caculate source whole-box base address */
    uint8_t *src_wbox_base0 = NULL;
    uint8_t *src_wbox_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        assert(box->x % 2 == 0);
        assert(box->y % 2 == 0);
        assert(box->w % 2 == 0);
        assert(box->h % 2 == 0);
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x;
        src_wbox_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            box->y / 2 * src->line_stride + box->x;
    } else if(src->format == BS_DATA_FMU2) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        src_wbox_base0 = (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        src_wbox_base0= (uint8_t *)src->base +
            box->y * src->line_stride + box->x * 4;
    } else {
        assert(0);
    }

    /* 2. caculate source whole-box base address */
    uint8_t *dst_wbox_base0 = (uint8_t *)(dst->base);
    uint8_t *dst_wbox_base1 = NULL;
    if (dst->format == BS_DATA_NV12) {
        dst_wbox_base1 = (uint8_t *)dst->base + dst->height * dst->line_stride;
    }

    /* 3. caculate destination/source sub-box information */
    float scale_x = (float)box->w / (float)dst->width;
    float scale_y = (float)box->h / (float)dst->height;
    float trans_x = 0.5*scale_x - 0.5;//0.5f;//fixme
    float trans_y = 0.5*scale_y - 0.5;//fixme

    const int sbox_num_w = (dst->width + BS_RESIZE_W - 1) / BS_RESIZE_W;
    const int sbox_num_h = (dst->height + BS_RESIZE_H - 1) / BS_RESIZE_H;
    int sbox_num = sbox_num_w * sbox_num_h;
    // caculate dst sub-box information
    box_info_s *dst_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (dst_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    int i, j;
    for (j = 0; j < sbox_num_h; j++) {
        for (i = 0; i < sbox_num_w; i++) {
            dst_sbox[j * sbox_num_w + i].x = i * BS_RESIZE_W;
            dst_sbox[j * sbox_num_w + i].y = j * BS_RESIZE_H;
            int sbox_w = (i == (sbox_num_w - 1)) ?
                (dst->width - 1) % BS_RESIZE_W + 1 : BS_RESIZE_W;
            int sbox_h = (j == (sbox_num_h - 1)) ?
                (dst->height - 1) % BS_RESIZE_H + 1 : BS_RESIZE_H;
            dst_sbox[j * sbox_num_w + i].w = sbox_w;
            dst_sbox[j * sbox_num_w + i].h = sbox_h;
        }
    }

    // caculate src sub-box information
    box_info_s *src_sbox = (box_info_s *)malloc(sizeof(box_info_s) * sbox_num);
    if (src_sbox == NULL) {
        fprintf(stderr, "alloc space failed!\n");
    }

    box_info_s wbox = {0, 0, box->w, box->h};
    for (int i = 0; i < sbox_num; i++) {
        resize_cac_sub_box(src_sbox + i, dst_sbox + i, &wbox,
                           scale_x, scale_y, trans_x, trans_y);
    }

    /* 4. caculate inverse matrix scale up exponent */
    // must after cac_sub_box !!!
    uint8_t y_gain_exp = 0;
    if (fabs(scale_y) < 1.0f) {// condition maybe error!!!//fixme
        y_gain_exp = get_exp(fabs(scale_y));
        assert(y_gain_exp > 0);
        scale_y *= (1 << y_gain_exp);
        trans_y *= (1 << y_gain_exp);
    }

    /* 5. most members of each sub-box are the same,
       only sub-box x,y,w,h are different. */
    bs_hw_once_cfg_s cfg;
    cfg.matrix[MSCALEX] = (int32_t)round(scale_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWX] = 0;
    cfg.matrix[MTRANSX] = (int32_t)round(trans_x * (1 << MAT_ACC));
    cfg.matrix[MSKEWY] = 0;
    cfg.matrix[MSCALEY] = (int32_t)round(scale_y * (1 << MAT_ACC));
    cfg.matrix[MTRANSY] = (int32_t)round(trans_y * (1 << MAT_ACC));

    cfg.y_gain_exp = y_gain_exp;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;

    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.affine = false;
    cfg.box_mode = true;

    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    cfg.zero_point = info->zero_point;
    cfg.box_num = 1;
    cfg.boxes_info = NULL;
    cfg.bus = 0; //fixme
    cfg.irq_mask = 1; //fixme
    cfg.isum = 0;
    cfg.osum = 0;

    for (int i = 0; i < sbox_num; i++) {
        uint8_t *src_sbox_base0 = NULL;
        uint8_t *src_sbox_base1 = NULL;
        if (src->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x;
            src_sbox_base1 = src_wbox_base0 + src->height * src->line_stride +
                src_sbox[i].y / 2 * src->line_stride + src_sbox[i].x;
        } else if(src->format == BS_DATA_FMU2) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 8;
        } else if(src->format == BS_DATA_FMU4) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 16;
        } else if(src->format == BS_DATA_FMU8) {
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 32;
        } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
            src_sbox_base0 = src_wbox_base0 +
                src_sbox[i].y * src->line_stride + src_sbox[i].x * 4;
        }

        cfg.src_base0 = src_sbox_base0;
        cfg.src_base1 = src_sbox_base1;

        cfg.src_box_x = src_sbox[i].x;
        cfg.src_box_y = src_sbox[i].y;
        cfg.src_box_w = src_sbox[i].w;
        cfg.src_box_h = src_sbox[i].h;

        uint8_t *dst_sbox_base0 = NULL;
        uint8_t *dst_sbox_base1 = NULL;
        if (dst->format == BS_DATA_NV12) {
            assert(box->x % 2 == 0);
            assert(box->y % 2 == 0);
            assert(box->w % 2 == 0);
            assert(box->h % 2 == 0);
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x;
            dst_sbox_base1 = dst_wbox_base0 + dst->height * dst->line_stride +
                dst_sbox[i].y / 2 * dst->line_stride + dst_sbox[i].x;
        } else if(dst->format == BS_DATA_FMU2) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 8;
        } else if(dst->format == BS_DATA_FMU4) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 16;
        } else if(dst->format == BS_DATA_FMU8) {
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 32;
        } else if (dst->format & 0x1) {//RGBA,ARGB, BRGA....
            dst_sbox_base0 = dst_wbox_base0 +
                dst_sbox[i].y * dst->line_stride + dst_sbox[i].x * 4;
        }

        cfg.dst_base[0] = dst_sbox_base0;
        cfg.dst_base[1] = dst_sbox_base1;
        cfg.dst_box_x = dst_sbox[i].x;
        cfg.dst_box_y = dst_sbox[i].y;
        cfg.dst_box_w = dst_sbox[i].w;
        cfg.dst_box_h = dst_sbox[i].h;

        bs_cfgs.push_back(cfg);
    }
    free(dst_sbox);
    free(src_sbox);
}

/**
 * resize line mode configure
 */
static void bs_resize_line_cfg_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs,
                                     std::vector<std::pair<int, const box_resize_info_s *>> &res_resize_boxes,
                                     const data_info_s *src, const data_info_s *dst,
                                     const uint32_t *coef, const uint32_t *offset)
{
#if 1
    std::vector<std::pair<int, const box_resize_info_s *>>::iterator it;
    for (it = res_resize_boxes.begin(); it != res_resize_boxes.end(); it++) {
        int idx = (*it).first;
        const box_resize_info_s *cur_box = (*it).second;
        const data_info_s *cur_dst = &(dst[idx]);
        bs_resize_cfg_stuff(bs_cfgs, cur_box, src, cur_dst, coef, offset);
    }
#else
    int box_num = res_resize_boxes.size();
    int tl_x = 65535, tl_y = 65535;
    int br_x = 0, br_y = 0;
    std::vector<std::pair<int, const box_resize_info_s *>>::iterator it;
    for (it = res_resize_boxes.begin(); it != res_resize_boxes.end(); it++) {
        int idx = (*it).first;
        const box_resize_info_s *cur_box = (*it).second;
        const data_info_s *cur_dst = &(dst[idx]);
        const box_info_s *ibox = &(cur_box->box);
        if (ibox->x < tl_x) {
            tl_x = ibox->x;
        }

        if (ibox->y < tl_y) {
            tl_y = ibox->y;
        }

        if ((ibox->x + ibox->w - 1) > br_x) {
            br_x = ibox->x + ibox->w - 1;
        }

        if ((ibox->y + ibox->h - 1) > br_y) {
            br_y = ibox->y + ibox->h - 1;
        }
    }
    box_info_s iwbox;
    iwbox.x = tl_x;
    iwbox.y = tl_y;
    iwbox.w = br_x - tl_x + 1;
    iwbox.h = br_y - tl_y + 1;

    bs_hw_once_cfg_s cfg;
    uint8_t *src_base1 = NULL;
    if (src->format == BS_DATA_NV12) {
        //assert(iwbox.x % 2 == 0);
        //assert(iwbox.y % 2 == 0);
        //assert(iwbox.w % 2 == 0);
        //assert(iwbox.h % 2 == 0);
        cfg.src_base0 = (uint8_t *)src->base +
            iwbox.y * src->line_stride + iwbox.x;
        src_base1 = (uint8_t *)src->base + src->height * src->line_stride +
            iwbox.y / 2 * src->line_stride + iwbox.x;
    } else if(src->format == BS_DATA_FMU2) {
        cfg.src_base0 = (uint8_t *)src->base +
            iwbox.y * src->line_stride + iwbox.x * 8;
    } else if(src->format == BS_DATA_FMU4) {
        cfg.src_base0 = (uint8_t *)src->base +
            iwbox.y * src->line_stride + iwbox.x * 16;
    } else if(src->format == BS_DATA_FMU8) {
        cfg.src_base0 = (uint8_t *)src->base +
            iwbox.y * src->line_stride + iwbox.x * 32;
    } else if (src->format & 0x1) {//RGBA,ARGB, BRGA....
        cfg.src_base0 = (uint8_t *)src->base +
            iwbox.y * src->line_stride + iwbox.x * 4;
    } else {
        assert(0);
    }

    cfg.src_base1 = src_base1;
    cfg.src_format = (bs_hw_data_format_e)src->format;
    cfg.src_line_stride = src->line_stride;
    cfg.src_box_x = 0;
    cfg.src_box_y = 0;
    cfg.src_box_w = iwbox.w;
    cfg.src_box_h = iwbox.h;

    cfg.dst_base[0] = (uint8_t *)(dst->base);
    cfg.dst_base[1] = NULL;
    cfg.dst_format = (bs_hw_data_format_e)dst->format;
    cfg.dst_line_stride = dst->line_stride;
    cfg.dst_box_x = 0;
    cfg.dst_box_y = 0;
    cfg.dst_box_w = dst->width;
    cfg.dst_box_h = dst->height;
    cfg.affine = false;
    cfg.box_mode = false;

    for (int i = 0; i < 9; i++) {
        cfg.coef[i] = coef[i];
    }
    for (int i = 0; i < 2; i++) {
        cfg.offset[i] = offset[i];
    }
    //max y gain exp
    uint8_t y_gain_exp_max = 0;
    for (it = res_resize_boxes.begin(); it != res_resize_boxes.end(); it++) {
        int idx = (*it).first;
        const box_resize_info_s *cur_info = (*it).second;
        const box_info_s *cur_box = &(cur_info->box);
        const data_info_s *cur_dst = &(dst[idx]);
        float scale_y = (float)cur_box->h / (float)cur_dst->height;
        uint8_t y_gain_exp = 0;
        if (fabs(scale_y) < 1.0f) {// condition maybe error!!!//fixme
            y_gain_exp = get_exp(fabs(scale_y));
            assert(y_gain_exp > 0);
            if (y_gain_exp > y_gain_exp_max) {
                y_gain_exp_max = y_gain_exp;
            }
        }
    }

    int cnt = 0;
    cfg.box_num = box_num;
    cfg.boxes_info = (uint32_t *)malloc(box_num * 6 * 4);//fixme, not free

    for (it = res_resize_boxes.begin(); it != res_resize_boxes.end(); it++) {
        int idx = (*it).first;
        const box_resize_info_s *cur_info = (*it).second;
        const box_info_s *cur_box = &(cur_info->box);
        const data_info_s *cur_dst = &(dst[idx]);
        float scale_y = (float)cur_box->h / (float)cur_dst->height;
        float scale_x = (float)cur_box->w / (float)cur_dst->width;
        float trans_x = 0.5f;
        float trans_y = 0.5f;
        if (y_gain_exp_max) {
            scale_y *= (1 << y_gain_exp_max);
            trans_y *= (1 << y_gain_exp_max);
        }
        cfg.zero_point = cur_info->zero_point;//fixme
        cfg.boxes_info[cnt * 6 + 0] = (((cur_box->x - iwbox.x) & 0xFFFF) << 16 |
                                       ((cur_box->y - iwbox.y) & 0xFFFF));
        cfg.boxes_info[cnt * 6 + 1] = ((cur_box->w & 0xFFFF) << 16 |
                                       (cur_box->h & 0xFFFF));
        cfg.boxes_info[cnt * 6 + 2] = (int32_t)(scale_x * 32768 + 0.5);
        cfg.boxes_info[cnt * 6 + 3] = (int32_t)(scale_y * 32768 + 0.5);
        cfg.boxes_info[cnt * 6 + 4] = (int32_t)(trans_x * 32768 + 0.5);
        cfg.boxes_info[cnt * 6 + 5] = (int32_t)(trans_y * 32768 + 0.5);
        cnt++;
    }

    cfg.y_gain_exp = y_gain_exp_max;
    cfg.osum = 0;//fixme
    cfg.isum = 0;//fixme
    bs_cfgs.push_back(cfg);
#endif
}

/**
 * generate chain, wrap bscaler software model.
 */
static void bs_chain_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs)
{
    /*for (int i = 0; i < bs_cfgs.size(); i++) {
        bs_hw_once_cfg_s *cfg = &(bs_cfgs[i]);
        bscaler_frmc_cfg(cfg);//do bscaler
		}*/
	//init chain info 
	uint32_t box_max_num = 64;
	uint32_t box_dst_max_w = 64;
	uint32_t cfg_reg_max = 22; 
	uint32_t bsc_chain_size = bs_cfgs.size() * (box_max_num + box_dst_max_w + cfg_reg_max) * 8;
	bsc_chain_base = (uint32_t *)malloc(bsc_chain_size);
	printf("CHAIN:0x%x,0x%x,%p\n",bs_cfgs.size(),bsc_chain_size,bsc_chain_base);

	if(bsc_chain_base ==NULL){
        printf("error : malloc bsc_chain_base is failed ! \n ");
    }
	uint32_t *bsc_chain_ptr = bsc_chain_base;
	uint32_t chain_len =0;

	for(int i=0; i<bs_cfgs.size(); i++){//frame n
		bs_chain_ret_s  back;
        bs_hw_once_cfg_s *bsc_cfg_once = &(bs_cfgs[i]);
        back = bscaler_frmc_chain_cfg(bsc_cfg_once, bsc_chain_ptr);//
        bsc_chain_ptr = back.bs_ret_base;
        chain_len = chain_len + back.bs_ret_len;
    }
	bs_chain_cfg_s chain_info;
	chain_info.bs_chain_base = bsc_chain_base;
	chain_info.bs_chain_len = chain_len;
	chain_info.bs_chain_irq = 1;
	//	start chain 
	bsc_chain_hw_cfg(chain_info);
}

/**
 * fake generate chain, wrap bscaler software model.
 */
static void fake_bs_chain_stuff(std::vector<bs_hw_once_cfg_s> &bs_cfgs)
{
    for (int i = 0; i < bs_cfgs.size(); i++) {
        bs_hw_once_cfg_s *cfg = &(bs_cfgs[i]);
        bscaler_mdl(cfg);//do bscaler
    }
}

////////////////////////////////////////////////////////////////////////////////
/**
 * for application developer
 */
int bs_covert_cfg(const data_info_s *src, const data_info_s *dst)
{

}

int bs_covert_step_start(const int line)
{
    //TODO
    //start bacler
}

int bs_covert_step_wait()
{
    //TODO
    //polling or wait for interrupt
}

int bs_cropbox_start(const data_info_s *src,
                     const int box_num, const data_info_s *dst,
                     const uint32_t *coef, const uint32_t *offset)
{

}

int bs_cropbox_wait()
{
    //TODO
    //polling or wait for interrupt
}

int bs_affine_start(const data_info_s *src,
                    const int box_num, const data_info_s *dst,
                    const box_affine_info_s *boxes,
                    const uint32_t *coef, const uint32_t *offset)
{
    /**********************************************************************
     1. classification, affine or resize
    **********************************************************************/
    std::vector<int> affine_boxes;
    std::vector<int> resize_boxes;
    for (int i = 0; i < box_num; i++) {
        if (affine_is_scale_translate(boxes[i].matrix)) {
            resize_boxes.push_back(i);
        } else {
            affine_boxes.push_back(i);
        }
    }

    /**********************************************************************
     2. affine box process
    **********************************************************************/
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    for (int i = 0; i < affine_boxes.size(); i++) {
        int idx = affine_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool affine_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        if (affine_split) {
            affine_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. resize box process
    **********************************************************************/
    for (int i = 0; i < resize_boxes.size(); i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        int idx = resize_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        if (resize_split) {
	        affine_resize_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_resize_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     4. stuff chain
    **********************************************************************/
    bs_chain_stuff(bs_cfgs);
}

int bs_affine_wait()
{
    //TODO
    //polling or wait for interrupt
    //polling
#if (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    int fail_flag = 0;
    while (((bscaler_read_reg(BSCALER_FRMC_CTRL, 0) & 0x3F) != 0) 
		   | ((bscaler_read_reg(BSCALER_FRMC_CHAIN_CTRL, 0) & 0x3) != 2)){
        fail_flag++;
        if (fail_flag >= 0x24000000) {
            printf("[Error] : time out!!\n");
            break;
        }
    }
	//free chain_base
	if(bsc_chain_base != NULL){
		free(bsc_chain_base);
		bsc_chain_base = NULL;
	}
#endif
}

int bs_perspective_start(const data_info_s *src,
                         const int box_num, const data_info_s *dst,
                         const box_affine_info_s *boxes,//fixme
                         const uint32_t *coef, const uint32_t *offset)
{
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    /**********************************************************************
     1. classification, perspective or affine or resize
    **********************************************************************/
    std::vector<int> perspective_boxes;
    std::vector<int> affine_boxes;
    std::vector<int> resize_boxes;
    for (int i = 0; i < box_num; i++) {
        if (affine_is_scale_translate(boxes[i].matrix)) {
            resize_boxes.push_back(i);
        } else {
            if (IS_ZERO(boxes[i].matrix[MPERSP0]) &&
                IS_ZERO(boxes[i].matrix[MPERSP1]) &&
                IS_ONE(boxes[i].matrix[MPERSP2])) {//affine
                affine_boxes.push_back(i);
            } else {//perspective
                perspective_boxes.push_back(i);
            }
        }
    }

    /**********************************************************************
     2. perspective box process
    **********************************************************************/
    for (int i = 0; i < perspective_boxes.size(); i++) {
        int idx = perspective_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool perspective_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        //printf("perspective_split = %d\n", perspective_split);
        if (perspective_split) {
            perspective_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_perspective_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. affine box process
    **********************************************************************/
    for (int i = 0; i < affine_boxes.size(); i++) {
        int idx = affine_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool affine_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        if (affine_split) {
            affine_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. resize box process
    **********************************************************************/
    for (int i = 0; i < resize_boxes.size(); i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        int idx = resize_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        if (resize_split) {
            affine_resize_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_resize_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     4. stuff chain
    **********************************************************************/
    bs_chain_stuff(bs_cfgs);
}

int bs_perspective_wait()
{
    //TODO
    //polling or wait for interrupt
#if (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    int fail_flag = 0;
    while (((bscaler_read_reg(BSCALER_FRMC_CTRL, 0) & 0x3F) != 0) 
		   | ((bscaler_read_reg(BSCALER_FRMC_CHAIN_CTRL, 0) & 0x3) != 2)){
        fail_flag++;
        if (fail_flag >= 0x24000000) {
            printf("[Error] : time out!!\n");
            break;
        }
    }
	//free chain_base
	if(bsc_chain_base != NULL){
		free(bsc_chain_base);
		bsc_chain_base = NULL;
	}
#endif
}

int bs_resize_start(const data_info_s *src,
                    const int box_num, const data_info_s *dst,
                    const box_resize_info_s *boxes,
                    const uint32_t *coef, const uint32_t *offset)
{
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    /**********************************************************************
     1. resize box process, pick up box of box part mode
    **********************************************************************/
    std::vector<std::pair<int, const box_resize_info_s *>> res_resize_boxes;
    for (int i = 0; i < box_num; i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        const box_resize_info_s *cur_box = &(boxes[i]);
        const data_info_s *cur_dst = &(dst[i]);
        if (resize_split) {
            resize_box_split(bs_cfgs, cur_box, src, cur_dst, coef, offset);
        } else {
            res_resize_boxes.push_back(std::make_pair(i, cur_box));
        }
    }

    /**********************************************************************
     2. resize line mode process
    **********************************************************************/
    bs_resize_line_cfg_stuff(bs_cfgs, res_resize_boxes, src, dst, coef, offset);

    /**********************************************************************
     3. stuff chain
    **********************************************************************/
    bs_chain_stuff(bs_cfgs);
}

int bs_resize_wait()
{
    //TODO
    //polling or wait for interrupt
#if (defined CHIP_SIM_ENV) || (defined EYER_SIM_ENV)
    int fail_flag = 0;
    while (((bscaler_read_reg(BSCALER_FRMC_CTRL, 0) & 0x3F) != 0) 
		   | ((bscaler_read_reg(BSCALER_FRMC_CHAIN_CTRL, 0) & 0x3) != 2)) {
        fail_flag++;
        if (fail_flag >= 0x24000000) {
            printf("[Error] : time out!!\n");
            break;
        }
    }
	//free chain_base
	if(bsc_chain_base != NULL){
		free(bsc_chain_base);
		bsc_chain_base = NULL;
	}
#endif
}

/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
int bs_resize_mdl(const data_info_s *src,
                  const int box_num, const data_info_s *dst,
                  const box_resize_info_s *boxes,
                  const uint32_t *coef, const uint32_t *offset)
{
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    /**********************************************************************
     1. resize box process, pick up box of box part mode
    **********************************************************************/
    std::vector<std::pair<int, const box_resize_info_s *>> res_resize_boxes;
    for (int i = 0; i < box_num; i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        const box_resize_info_s *cur_box = &(boxes[i]);
        const data_info_s *cur_dst = &(dst[i]);
        if (resize_split) {
            resize_box_split(bs_cfgs, cur_box, src, cur_dst, coef, offset);
        } else {
            res_resize_boxes.push_back(std::make_pair(i, cur_box));
        }
    }

    /**********************************************************************
     2. resize line mode process
    **********************************************************************/
    bs_resize_line_cfg_stuff(bs_cfgs, res_resize_boxes, src, dst, coef, offset);

    /**********************************************************************
     3. stuff chain
    **********************************************************************/
    fake_bs_chain_stuff(bs_cfgs);
}

int bs_affine_mdl(const data_info_s *src,
                  const int box_num, const data_info_s *dst,
                  const box_affine_info_s *boxes,
                  const uint32_t *coef, const uint32_t *offset)
{
    /**********************************************************************
     1. classification, affine or resize
    **********************************************************************/
    std::vector<int> affine_boxes;
    std::vector<int> resize_boxes;
    for (int i = 0; i < box_num; i++) {
        if (affine_is_scale_translate(boxes[i].matrix)) {
            resize_boxes.push_back(i);
        } else {
            affine_boxes.push_back(i);
        }
    }

    /**********************************************************************
     2. affine box process
    **********************************************************************/
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    for (int i = 0; i < affine_boxes.size(); i++) {
        int idx = affine_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool affine_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        if (affine_split) {
            affine_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. resize box process
    **********************************************************************/
    for (int i = 0; i < resize_boxes.size(); i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        int idx = resize_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        if (resize_split) {
            affine_resize_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_resize_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     4. stuff chain
    **********************************************************************/
    fake_bs_chain_stuff(bs_cfgs);
}

int bs_perspective_mdl(const data_info_s *src,
                       const int box_num, const data_info_s *dst,
                       const box_affine_info_s *boxes,//fixme
                       const uint32_t *coef, const uint32_t *offset)
{
    std::vector<bs_hw_once_cfg_s> bs_cfgs;
    /**********************************************************************
     1. classification, perspective or affine or resize
    **********************************************************************/
    std::vector<int> perspective_boxes;
    std::vector<int> affine_boxes;
    std::vector<int> resize_boxes;
    for (int i = 0; i < box_num; i++) {
        if (affine_is_scale_translate(boxes[i].matrix)) {
            resize_boxes.push_back(i);
        } else {
            if (IS_ZERO(boxes[i].matrix[MPERSP0]) &&
                IS_ZERO(boxes[i].matrix[MPERSP1]) &&
                IS_ONE(boxes[i].matrix[MPERSP2])) {//affine
                affine_boxes.push_back(i);
            } else {//perspective
                perspective_boxes.push_back(i);
            }
        }
    }

    /**********************************************************************
     2. perspective box process
    **********************************************************************/
    for (int i = 0; i < perspective_boxes.size(); i++) {
        int idx = perspective_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool perspective_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        if (perspective_split) {
            perspective_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_perspective_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. affine box process
    **********************************************************************/
    for (int i = 0; i < affine_boxes.size(); i++) {
        int idx = affine_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        bool affine_split = (cur_dst.width > 64) || (cur_dst.height > 64);
        if (affine_split) {
            affine_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     3. resize box process
    **********************************************************************/
    for (int i = 0; i < resize_boxes.size(); i++) {
        bool resize_split = (dst->width > BS_RESIZE_W) || (dst->height > BS_RESIZE_H);
        int idx = resize_boxes[i];
        box_affine_info_s cur_box = boxes[idx];
        data_info_s cur_dst = dst[idx];
        if (resize_split) {
            affine_resize_box_split(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        } else {
            bs_affine_resize_cfg_stuff(bs_cfgs, &cur_box, src, &cur_dst, coef, offset);
        }
    }

    /**********************************************************************
     4. stuff chain
    **********************************************************************/
    fake_bs_chain_stuff(bs_cfgs);
}
