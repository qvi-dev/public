
#include <stdio.h>
#include "LocalMemMgr.h"

static void *mp_memory = NULL;
static unsigned int mp_memory_size = 0;

int ddr_memory_init (void *mp, unsigned int mp_size)
{
  mp_memory_size = mp_size;
  mp_memory = mp;
  return Local_HeapInit (mp_memory, mp_memory_size);
}

void ddr_memory_deinit (void)
{
  mp_memory = NULL;
  mp_memory_size = 0;
}

void *ddr_malloc (unsigned int size)
{
  void *ret = Local_Alloc (mp_memory, size);
  return ret;
}

void ddr_free (void *addr)
{
  if (addr != NULL)
    Local_Dealloc (mp_memory, addr);
}

void *ddr_calloc (unsigned int size, unsigned int n)
{
  void *ret = Local_Calloc(mp_memory, size, n);
  return ret;
}

void *ddr_realloc (void *addr, unsigned int size)
{
  void *ret = Local_Realloc (mp_memory, addr, size);
  return ret;
}

void *ddr_memalign (unsigned int align, unsigned int size)
{
  void *ret = Local_alignAlloc (mp_memory, align, size);
  return ret;
}

